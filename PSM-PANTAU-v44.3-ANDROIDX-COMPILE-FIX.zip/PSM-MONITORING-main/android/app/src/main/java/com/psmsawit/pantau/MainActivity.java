package com.psmsawit.pantau;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private WebView webView;
    private String pendingFilename = "PSM_GAMBAR.png";
    private String pendingMime = "image/png";
    private StringBuilder pendingBase64 = new StringBuilder();
    private boolean pendingTooLarge = false;
    private static final int MAX_BASE64_CHARS = 24 * 1024 * 1024;
    private static final int MAX_TEXT_BYTES = 12 * 1024 * 1024;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        registerPlugin(LegacyAndroidBridgePlugin.class);
        super.onCreate(savedInstanceState);
        if (getBridge() == null || getBridge().getWebView() == null) {
            Toast.makeText(getApplicationContext(), "Komponen Capacitor gagal dimuat", Toast.LENGTH_LONG).show(); finish(); return;
        }
        webView = getBridge().getWebView();
        setupWindowSafeArea();
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false); s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setDownloadListener((url, ua, disposition, mime, length) -> {
            try { Uri uri=Uri.parse(url); if ("https".equalsIgnoreCase(uri.getScheme())) startActivity(new Intent(Intent.ACTION_VIEW,uri));
            else Toast.makeText(getApplicationContext(),"Tautan unduhan tidak diizinkan",Toast.LENGTH_SHORT).show(); }
            catch(Exception e){Toast.makeText(getApplicationContext(),"Tidak dapat membuka unduhan",Toast.LENGTH_SHORT).show();}
        });
    }

    public class AndroidBridge {
        @JavascriptInterface public void openExternalUrl(String rawUrl) {
            try {
                if (rawUrl == null || rawUrl.length() > 8192) throw new Exception("Tautan tidak valid");
                Uri uri = Uri.parse(rawUrl);
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                Intent intent;
                if ("intent".equals(scheme)) {
                    intent = Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME);
                } else if ("https".equals(scheme) || "http".equals(scheme) || "whatsapp".equals(scheme)) {
                    intent = new Intent(Intent.ACTION_VIEW, uri);
                } else {
                    throw new Exception("Jenis tautan tidak diizinkan");
                }
                if (intent.resolveActivity(getPackageManager()) != null) startActivity(intent);
                else runOnUiThread(() -> Toast.makeText(MainActivity.this.getApplicationContext(), "Aplikasi tujuan tidak ditemukan", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this.getApplicationContext(), "Tidak dapat membuka tautan: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }
        @JavascriptInterface public synchronized void beginBase64File(String filename,String mime){pendingFilename=sanitizeFilename(filename==null?"PSM_GAMBAR.png":filename);pendingMime=safeMime(mime);pendingBase64=new StringBuilder();pendingTooLarge=false;}
        @JavascriptInterface public synchronized void appendBase64Chunk(String chunk){if(chunk==null||pendingTooLarge)return;if(pendingBase64.length()+chunk.length()>MAX_BASE64_CHARS){pendingBase64=new StringBuilder();pendingTooLarge=true;return;}pendingBase64.append(chunk);}
        @JavascriptInterface public synchronized void finishBase64File(){String name=pendingFilename,mime=pendingMime,encoded=pendingBase64.toString();boolean tooLarge=pendingTooLarge;pendingBase64=new StringBuilder();pendingTooLarge=false;if(tooLarge){runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"Gagal simpan: ukuran file melebihi batas",Toast.LENGTH_LONG).show());return;}try{byte[] b=Base64.decode(encoded,Base64.DEFAULT);if(b.length>18*1024*1024)throw new Exception("File terlalu besar");saveBytesToDownloads(name,mime,b);runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"File tersimpan di Download: "+name,Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"Gagal simpan file: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
        @JavascriptInterface public void saveBase64File(String filename,String dataUrl){try{String name=sanitizeFilename(filename==null?"PSM_GAMBAR.png":filename);if(dataUrl==null||dataUrl.length()>MAX_BASE64_CHARS+256)throw new Exception("File terlalu besar atau kosong");String b64=dataUrl,mime="image/png";if(dataUrl.startsWith("data:")){int comma=dataUrl.indexOf(',');if(comma<0)throw new Exception("Format data gambar tidak valid");String meta=dataUrl.substring(5,comma);if(meta.contains(";"))mime=meta.substring(0,meta.indexOf(';'));b64=dataUrl.substring(comma+1);}byte[] bytes=Base64.decode(b64,Base64.DEFAULT);if(bytes.length>18*1024*1024)throw new Exception("File terlalu besar");saveBytesToDownloads(name,safeMime(mime),bytes);runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"File tersimpan di Download: "+name,Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"Gagal simpan file: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
        @JavascriptInterface public void saveTextFile(String filename,String text,String mime){try{String name=sanitizeFilename(filename==null?"PSM_DATA.txt":filename);byte[] b=(text==null?"":text).getBytes(StandardCharsets.UTF_8);if(b.length>MAX_TEXT_BYTES)throw new Exception("File teks terlalu besar");saveBytesToDownloads(name,safeMime(mime),b);runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"File tersimpan di Download: "+name,Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"Gagal simpan file: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
    }

    public class AndroidShareBridge {
        @JavascriptInterface public void shareText(String text){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text==null?"":text);startActivity(Intent.createChooser(i,"Bagikan melalui"));});}
        @JavascriptInterface public void shareBase64File(String filename,String mime,String base64){try{if(base64==null||base64.length()>MAX_BASE64_CHARS)throw new Exception("File terlalu besar");byte[] bytes=Base64.decode(base64,Base64.DEFAULT);if(bytes.length>18*1024*1024)throw new Exception("File terlalu besar");String name=sanitizeFilename(filename==null?"PSM_BERKAS":filename);File dir=new File(getCacheDir(),"shared");if(!dir.exists()&&!dir.mkdirs())throw new Exception("Folder sementara tidak dapat dibuat");File f=new File(dir,name);try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);out.flush();}Uri uri=FileProvider.getUriForFile(MainActivity.this.getApplicationContext(),getPackageName()+".fileprovider",f);runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType(safeMime(mime));i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Bagikan berkas"));});}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this.getApplicationContext(),"Gagal membagikan berkas: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
    }
    private String safeMime(String mime){if(mime==null)return "application/octet-stream";String m=mime.trim().toLowerCase(Locale.ROOT);if(m.equals("image/png")||m.equals("image/jpeg")||m.equals("image/webp")||m.equals("text/plain")||m.equals("text/csv")||m.equals("application/json")||m.equals("application/vnd.ms-excel")||m.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")||m.equals("application/octet-stream"))return m;return "application/octet-stream";}
    private String sanitizeFilename(String name){if(name==null)name="PSM_DATA";String s=name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+","_").replaceAll("\\s+","_");if(s.length()>160)s=s.substring(0,160);if(!s.contains("."))s+=".png";return s;}
    private void saveBytesToDownloads(String filename,String mime,byte[] bytes)throws Exception{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,filename);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.IS_PENDING,1);Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception("Tidak bisa membuat file Download");try{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("OutputStream kosong");out.write(bytes);out.flush();}v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);if(getContentResolver().update(uri,v,null,null)<=0)throw new Exception("Gagal menyelesaikan file Download");}catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}}else{File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);if(!d.exists()&&!d.mkdirs())throw new Exception("Folder Download tidak dapat dibuat");try(FileOutputStream out=new FileOutputStream(new File(d,filename))){out.write(bytes);}}}
    private void setupWindowSafeArea(){Window w=getWindow();w.setStatusBarColor(Color.rgb(125,186,145));w.setNavigationBarColor(Color.rgb(250,251,245));if(Build.VERSION.SDK_INT>=23)w.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);}
    @Override public void onBackPressed(){if(webView==null){super.onBackPressed();return;}webView.evaluateJavascript("(function(){try{if(window.handleAndroidBack){return window.handleAndroidBack()?'1':'0'}return '0'}catch(e){return '0'}})();",value->{if("true".equals(value)||"\"1\"".equals(value)||"1".equals(value))return;if(webView!=null&&webView.canGoBack())webView.goBack();else MainActivity.super.onBackPressed();});}
}
