const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const packaged=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('all PIN fields request numeric keypad and remain visually masked',()=>{
 for(const id of ['input-pin','pin-setup-new','pin-setup-confirm','pin-lama','pin-baru']){
  const tag=html.match(new RegExp('<input[^>]*id="'+id+'"[^>]*>'))?.[0]||'';
  assert.ok(tag.includes('type="tel"'));
  assert.ok(tag.includes('inputmode="numeric"'));
  assert.ok(tag.includes('pattern="[0-9]*"'));
 }
 assert.ok(html.includes('-webkit-text-security:disc'));
 assert.ok(!html.includes('ime-mode:disabled'));
});

test('text and number fields use static keyboard hints without focus-time mutation',()=>{
 assert.ok(!html.includes('psm-keyboard-input-runtime'));
 assert.ok(!html.includes('new MutationObserver(records=>records.forEach(r=>r.addedNodes'));
 assert.ok(html.includes('autocorrect="off"'));
 assert.ok(html.includes('autocapitalize="off"'));
 assert.ok(html.includes('spellcheck="false"'));
 assert.ok(html.includes('inputmode="decimal"'));
});

test('activity timestamp is not written for every keydown event',()=>{
 const fn=html.match(/function pasangPencatatAktivitasPantau\(\)\{[^}]*\}/)?.[0]||'';
 assert.ok(fn);
 assert.ok(!fn.includes('keydown'));
 assert.ok(fn.includes('pointerdown'));
});

test('app does not intercept keyboard editing or IME composition events globally',()=>{
 assert.ok(!['document.addEventListener(\'keydown','document.addEventListener(\'keyup','document.addEventListener(\'beforeinput','document.addEventListener(\'compositionstart','document.addEventListener(\'compositionend','document.addEventListener("keydown','document.addEventListener("keyup','document.addEventListener("beforeinput'].some(x=>html.includes(x)));
 assert.ok(!['window.addEventListener(\'keydown','window.addEventListener(\'keyup','window.addEventListener(\'beforeinput','window.addEventListener(\'compositionstart','window.addEventListener(\'compositionend','window.addEventListener("keydown','window.addEventListener("keyup','window.addEventListener("beforeinput'].some(x=>html.includes(x)));
});

test('web and Android packaged assets are identical',()=>assert.equal(html,packaged));
