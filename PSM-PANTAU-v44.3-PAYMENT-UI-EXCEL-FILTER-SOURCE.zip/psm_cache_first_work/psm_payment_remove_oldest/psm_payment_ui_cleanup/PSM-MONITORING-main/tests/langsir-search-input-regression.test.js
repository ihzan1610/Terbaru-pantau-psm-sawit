const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('ongkos search uses a plain text input with mobile keyboard correction disabled', () => {
  const tag = html.match(/<input[^>]*id="pl-search"[^>]*>/)?.[0] || '';
  assert.match(tag, /type="text"/);
  assert.match(tag, /autocorrect="off"/);
  assert.match(tag, /autocapitalize="off"/);
  assert.match(tag, /spellcheck="false"/);
  assert.match(tag, /oncompositionend="renderPantauLangsirDrivers\(this\)"/);
});

test('gaji search uses a plain text input with mobile keyboard correction disabled', () => {
  const tag = html.match(/<input[^>]*id="pl-gaji-search"[^>]*>/)?.[0] || '';
  assert.match(tag, /type="text"/);
  assert.match(tag, /autocorrect="off"/);
  assert.match(tag, /autocapitalize="off"/);
  assert.match(tag, /spellcheck="false"/);
  assert.match(tag, /oncompositionend="renderPantauGajiDrivers\(this\)"/);
});

test('search rendering reads the input without rewriting its value or replacing the input node', () => {
  const ongkos = html.slice(html.indexOf('window.renderPantauLangsirDrivers='), html.indexOf('window.togglePantauLangsirDriver='));
  const gaji = html.slice(html.indexOf('window.renderPantauGajiDrivers='), html.indexOf('window.togglePantauGajiDriver='));
  for (const block of [ongkos, gaji]) {
    assert.match(block, /input\.isComposing/);
    assert.match(block, /String\(input\.value\|\|''\)/);
    assert.doesNotMatch(block, /input\.value\s*=/);
    assert.doesNotMatch(block, /pl-search['"]\)\.outerHTML/);
  }
});

test('web and Android packaged HTML assets are identical', () => {
  assert.equal(html, packaged);
});
