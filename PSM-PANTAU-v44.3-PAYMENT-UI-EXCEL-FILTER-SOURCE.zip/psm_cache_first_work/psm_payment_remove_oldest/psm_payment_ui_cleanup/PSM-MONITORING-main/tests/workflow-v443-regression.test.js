const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
test('v44.3 workflow targets the actual Capacitor project structure',()=>{
 const w=fs.readFileSync(path.join(root,'.github/workflows/build-debug-apk.yml'),'utf8');
 for(const f of ['package.json','capacitor.config.json','www/index.html','android/settings.gradle','android/app/build.gradle']) assert.ok(w.includes(f));
 assert.match(w,/npx cap sync android/);
 assert.match(w,/gradle assembleDebug/);
 assert.doesNotMatch(w,/android-actions\/setup-android/);
});
test('vendor copy script resolves package assets rather than hardcoded dist paths',()=>{
 const s=fs.readFileSync(path.join(root,'scripts/copy-vendor-assets.js'),'utf8');
 assert.match(s,/require\.resolve/);
 assert.match(s,/html2canvas/);
 assert.match(s,/xlsx/);
});

test('release workflow accepts v44.3 source ZIP suffix variants but requires exactly one',()=>{
 const w=fs.readFileSync(path.join(root,'.github/workflows/build-debug-apk.yml'),'utf8');
 assert.match(w,/PSM-PANTAU-v44\.3\*\.zip/);
 assert.match(w,/Harus ada tepat satu ZIP sumber v44\.3/);
 assert.match(w,/sha256sum/);
});
test('Gradle settings allow Capacitor plugin repositories without settings conflict',()=>{
 const s=fs.readFileSync(path.join(root,'android/settings.gradle'),'utf8');
 assert.match(s,/RepositoriesMode\.PREFER_PROJECT/);
 assert.doesNotMatch(s,/RepositoriesMode\.FAIL_ON_PROJECT_REPOS/);
});

test('Android app declares AppCompat required by Capacitor BridgeActivity',()=>{
 const g=fs.readFileSync(path.join(root,'android/app/build.gradle'),'utf8');
 assert.match(g,/androidx\.appcompat:appcompat:1\.7\.0/);
 const p=fs.readFileSync(path.join(root,'android/app/src/main/java/com/psmsawit/pantau/LegacyAndroidBridgePlugin.java'),'utf8');
 assert.match(p,/com\.getcapacitor\.annotation\.CapacitorPlugin/);
});
