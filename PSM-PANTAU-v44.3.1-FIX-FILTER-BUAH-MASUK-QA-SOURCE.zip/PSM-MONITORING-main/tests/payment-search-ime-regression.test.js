const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const packaged=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('payment search disables autocorrect and capitalization transformations',()=>{
 const tag=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 for(const attr of ['autocomplete="off"','autocapitalize="off"','autocorrect="off"','spellcheck="false"','inputmode="search"'])assert.ok(tag.includes(attr),attr);
});

test('payment search does not rerender on every raw keystroke',()=>{
 const tag=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 assert.match(tag,/oninput="handlePaymentSearchInput\(event\)"/);
 assert.doesNotMatch(tag,/oninput="renderPaymentPage\(\)"/);
 assert.match(html,/paymentSearchRenderTimer=setTimeout\(\(\)=>\{paymentSearchRenderTimer=null;renderPaymentPage\(\)\},320\)/);
});

test('IME composition is allowed to finish before search refresh',()=>{
 const tag=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 assert.match(tag,/oncompositionstart=/);
 assert.match(tag,/oncompositionend="paymentSearchComposing=false;handlePaymentSearchInput\(event\)"/);
 assert.match(html,/if\(paymentSearchComposing\|\|event\?\.isComposing\)return/);
});

test('web and Android payment search implementations are identical',()=>assert.equal(html,packaged));
