const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const packaged=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('all PIN fields request numeric keypad and retain visual masking',()=>{
 for(const id of ['input-pin','pin-setup-new','pin-setup-confirm','pin-lama','pin-baru']){
  const tag=html.match(new RegExp('<input[^>]*id="'+id+'"[^>]*>'))?.[0]||'';
  assert.ok(tag.includes('type="tel"'));
  assert.ok(tag.includes('inputmode="numeric"'));
  assert.ok(tag.includes('pattern="[0-9]*"'));
 }
 assert.ok(html.includes('-webkit-text-security:disc'));
});

test('text inputs disable autocorrect and spellcheck',()=>{
 assert.ok(html.includes('function prepareInput(el)'));
 assert.ok(html.includes("setAttribute('autocorrect','off')"));
 assert.ok(html.includes("setAttribute('autocapitalize','off')"));
 assert.ok(html.includes("setAttribute('spellcheck','false')"));
});

test('keyboard compatibility layer does not intercept deletion or IME composition',()=>{
 const start=html.indexOf('id="psm-keyboard-input-runtime"');
 const block=html.slice(start,html.indexOf('</script>',start));
 assert.ok(!block.includes('preventDefault'));
 assert.ok(!block.includes('stopPropagation'));
 assert.ok(block.includes('Do not intercept keydown, beforeinput, Backspace, Delete, or composition events'));
});

test('numeric fields receive numeric or decimal input mode when unspecified',()=>{
 assert.ok(html.includes("el.type==='number'&&!el.hasAttribute('inputmode')"));
 assert.ok(html.includes("el.step==='any'?'decimal':'numeric'"));
});

test('web and Android packaged assets remain identical',()=>assert.equal(html,packaged));
