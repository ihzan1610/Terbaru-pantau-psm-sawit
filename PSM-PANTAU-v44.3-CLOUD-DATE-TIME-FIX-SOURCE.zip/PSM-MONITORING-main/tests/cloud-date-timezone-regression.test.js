const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html = fs.readFileSync(path.resolve(__dirname, '../www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.resolve(__dirname, '../android/app/src/main/assets/index.html'), 'utf8');

function loadFunction(name, nextName) {
  const re = new RegExp(`function ${name}\\([\\s\\S]*?\\n\\}`);
  const match = html.match(re);
  assert.ok(match, `${name} exists`);
  const context = { Date };
  vm.createContext(context);
  vm.runInContext(match[0] + `;this.fn=${name};`, context);
  return context.fn;
}
const cloudDate = loadFunction('formatTanggalCloud');
const cloudTime = loadFunction('formatJamCloud');

test('date-only ISO and slash dates are preserved as calendar dates', () => {
  assert.equal(cloudDate('2026-11-07'), '2026-11-07');
  assert.equal(cloudDate('07/11/2026'), '2026-11-07');
  assert.equal(cloudDate('07/11/26'), '2026-11-07');
});

test('Admin ISO midnight WITA timestamp maps to the same WITA calendar date', () => {
  assert.equal(cloudDate('2026-11-06T16:00:00.000Z'), '2026-11-07');
  assert.equal(cloudDate('2026-11-05T16:00:00.000Z'), '2026-11-06');
  assert.equal(cloudDate('2026-11-07T00:00:00+08:00'), '2026-11-07');
});

test('Cloud calendar conversion is independent of Android device timezone', () => {
  const old = process.env.TZ;
  try {
    for (const tz of ['UTC', 'Asia/Jakarta', 'Asia/Makassar', 'America/Los_Angeles']) {
      process.env.TZ = tz;
      assert.equal(cloudDate('2026-11-06T16:00:00.000Z'), '2026-11-07', tz);
      assert.equal(cloudTime('1899-12-30T10:19:24.000Z'), '18:19:24', tz);
    }
  } finally {
    if (old === undefined) delete process.env.TZ; else process.env.TZ = old;
  }
});

test('Cloud time values normalize dot, colon, and Google Sheets ISO forms', () => {
  assert.equal(cloudTime('16.38.44'), '16:38:44');
  assert.equal(cloudTime('08:48:00'), '08:48:00');
  assert.equal(cloudTime('1899-12-30T10:19:24.000Z'), '18:19:24');
  assert.equal(cloudTime('2010-08-19T16:00:00.000Z'), '00:00:00');
});

test('invalid Cloud dates are rejected instead of silently replaced with today', () => {
  assert.equal(cloudDate('not-a-date'), '');
  assert.match(html, /if\(!normalized\.date\)throw new Error\('Tanggal Cloud tidak valid/);
});

test('declared Cloud count must match the actual data array before replacement', () => {
  assert.match(html, /Number\(j\.count\)!==j\.data\.length/);
});

test('web and packaged Android HTML remain identical', () => {
  assert.equal(html, packaged);
});
