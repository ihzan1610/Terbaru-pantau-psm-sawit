# Laporan perbaikan sinkronisasi tanggal dan jam Cloud — Pantau PSM v44.3

## Sumber pemeriksaan
- Arsip sumber: PSM-PANTAU-v44.3-CLOUD-DATE-FIX-SOURCE.zip
- Respons API yang diberikan pengguna: echo.json
- Jumlah respons Cloud: 2.332 transaksi (`count=2332`, `data.length=2332`)

## Temuan pada respons Cloud
- Kolom `date` memiliki dua representasi: tanggal kalender `DD/MM/YYYY` dan timestamp ISO UTC.
- Seluruh 1.307 nilai `date` berbentuk timestamp ISO pada file ini menggunakan jam `16:00:00Z`, yang merepresentasikan pukul 00:00 WITA pada hari kalender berikutnya.
- Kolom `time` juga tidak seragam: sebagian berupa `HH.mm.ss`/`HH:mm:ss`, sebagian berupa timestamp ISO dari serial tanggal/jam Google Sheets.
- Karena itu, konversi tanggal berdasarkan zona waktu perangkat tidak cukup deterministik. Jam perangkat yang berbeda dapat menghasilkan tanggal tampilan yang berbeda.

## Perubahan kode
1. Menambahkan `formatTanggalCloud()` untuk normalisasi tanggal Cloud dengan kalender tetap WITA (UTC+08:00), bukan zona waktu perangkat.
2. Tanggal kalender `YYYY-MM-DD`, `DD/MM/YYYY`, dan `DD/MM/YY` dipertahankan sebagai tanggal kalender tanpa pergeseran.
3. Timestamp ISO dengan zona waktu eksplisit dikonversi menggunakan offset tetap UTC+08:00.
4. Menambahkan `formatJamCloud()` untuk menormalisasi jam bertitik, jam berkolon, dan timestamp ISO Google Sheets menjadi `HH:mm:ss` WITA.
5. Sinkronisasi menolak tanggal Cloud yang tidak valid; tidak lagi menggantinya diam-diam dengan tanggal hari ini.
6. Sinkronisasi memeriksa `count` terhadap panjang array `data` sebelum mengganti snapshot lokal.
7. Sumber `www/index.html` dan aset Android `android/app/src/main/assets/index.html` dibuat identik.
8. Tidak mengubah operasi tulis Cloud. Pantau tetap hanya membaca Cloud melalui GET dan menyimpan transaksi darurat secara lokal.

## Pengujian
- `npm test`: 94 tes lulus, 0 gagal.
- Regresi zona waktu diuji di UTC, Asia/Jakarta, Asia/Makassar, dan America/Los_Angeles.
- Contoh `2026-11-06T16:00:00.000Z` selalu menjadi `2026-11-07`, terlepas dari zona waktu perangkat.
- Jam contoh `1899-12-30T10:19:24.000Z` selalu menjadi `18:19:24` WITA.
- Pengujian respons `echo.json`: seluruh 2.332 ID unik dan tanggal berhasil dinormalisasi.
- Belum dilakukan build APK maupun pengujian cetak/antarmuka langsung pada perangkat Android.

## Batasan
Perbaikan ini mengikuti zona waktu WITA (UTC+08:00), sesuai representasi timestamp 16:00Z pada data Cloud dan konteks operasional Samarinda. Jika Admin PSM SAWIT sebenarnya menggunakan zona waktu berbeda, perlu konfirmasi sebelum mengganti offset.
