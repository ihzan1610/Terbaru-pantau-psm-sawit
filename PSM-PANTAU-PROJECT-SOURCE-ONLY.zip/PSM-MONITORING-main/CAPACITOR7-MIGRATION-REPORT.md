# Laporan Migrasi Capacitor 7 — Checkpoint

## Sumber
- Baseline: PSM-PANTAU-v42.0-VERIFIED-DATA-MIGRATION
- Application ID dipertahankan: `com.psmsawit.pantau`
- Version code: 43
- Version name: `43.0-capacitor7`

## Yang diterapkan
- Capacitor Core, Android, dan CLI dipatok pada 7.6.10.
- Struktur proyek Android dipindahkan ke format standar `android/`.
- Sumber web dipindahkan ke `www/index.html`; file lama tetap disimpan sebagai referensi.
- `MainActivity` memakai `BridgeActivity`.
- Plugin kompatibilitas native didaftarkan sebelum WebView dimuat untuk mempertahankan `window.Android` dan `window.AndroidShare`.
- Fungsi simpan file/gambar, simpan teks, berbagi teks/berkas, tautan intent RAWBT, dan tombol kembali dipertahankan.
- Pemilih file memakai `BridgeWebChromeClient` milik Capacitor.
- GitHub Actions disiapkan dengan Node 22, JDK 21, Gradle 8.11.1, Android SDK, pengujian, sinkronisasi Capacitor, dan build APK.

## Verifikasi yang dilakukan
- Tes regresi JavaScript: 60/60 lulus sebelum pemeriksaan sinkronisasi sumber terakhir.
- Konfigurasi JSON dan XML Android valid.
- ZIP diperiksa integritasnya setelah dibuat.

## Belum diverifikasi / bukan klaim selesai
- Build Gradle aktual dan hasil APK: belum dapat dijalankan pada lingkungan ini karena dependensi npm/Android SDK tidak tersedia dan instalasi npm lokal timeout.
- Uji perangkat Android fisik: belum dilakukan.
- Migrasi penyimpanan runtime penuh ke IndexedDB: belum dilakukan.
- Enkripsi seluruh transaksi dengan Android Keystore: belum dilakukan.

## Catatan data
Migrasi Capacitor ini tidak mengubah rumus bisnis, kunci database lokal, maupun aturan Cloud GET-only. Simpan backup data sebelum menguji APK di atas instalasi yang berisi data penting.
