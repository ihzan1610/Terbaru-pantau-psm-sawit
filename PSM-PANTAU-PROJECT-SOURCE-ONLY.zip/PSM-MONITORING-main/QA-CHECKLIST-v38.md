# QA Checklist PSM Pantau v38.0

- [x] Pemisahan storage Cloud / lokal / arsip tetap berlaku.
- [x] Cloud refresh hanya GET; tidak mengirim transaksi lokal.
- [x] Data Cloud tetap tidak dapat diedit/dihapus dari Pantau.
- [x] Rekonsiliasi mengarsipkan transaksi lokal yang cocok dan tidak memasukkannya ke daftar aktif.
- [x] Tes invariants Buah Masuk dan Pembayaran lulus.
- [x] Format gambar Buah Masuk 500px dan capture 3x.
- [x] Workflow APK mengunduh html2canvas 1.4.1 lalu menyalinnya ke aset lokal sebelum build.
- [x] Pengaturan nama penimbang dan logo lokal tersedia.
- [x] Thermal satu transaksi diarahkan ke slip individual.
- [x] Thermal multi transaksi tetap diarahkan ke rekap.
- [x] Pengaturan bitmap logo thermal dihormati.
- [x] Metadata versi Android 38.0.
- [ ] Uji APK di perangkat Android nyata.
- [ ] Uji printer thermal 58mm dan 80mm nyata.
