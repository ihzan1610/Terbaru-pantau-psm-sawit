# Laporan Perbaikan Pantau PSM v37.0

## Fokus rilis
Memperbaiki aturan data lokal darurat dan sinkronisasi Buah Masuk sesuai keputusan pengguna. Mempertahankan fungsi umum dan halaman Buah Keluar/Pabrik.

## Perubahan fungsional
1. Tombol utama Cloud diubah menjadi **COCOKKAN DENGAN CLOUD**.
2. Saat ditekan, aplikasi meminta konfirmasi, mengambil Cloud terbaru melalui HTTP GET, lalu mengarsipkan seluruh data lokal darurat aktif.
3. Data lokal yang cocok diberi `matchedCloudId` dan status cocok. Data yang belum cocok tetap diarsipkan dengan alasan `manual-cloud-reconcile-unmatched`; tidak dihapus.
4. Setelah proses berhasil, daftar aktif berisi snapshot resmi Cloud saja. Status pembayaran dan isi transaksi lokal tetap dipertahankan dalam arsip.
5. Saat aplikasi dibuka, jika jeda sejak aktivitas terakhir minimal 1 jam, seluruh data darurat aktif dipindahkan ke arsip sebelum pengambilan Cloud.
6. Tidak ada sinkronisasi berkala, polling 60 detik, pemicu saat online, atau pembaruan saat aplikasi kembali terlihat. Cloud hanya ditarik sekali saat aplikasi dibuka/unlock atau saat tombol Cocokkan ditekan.
7. Jika pengarsipan lokal gagal, data lokal aktif tidak dikosongkan. Jika Cloud gagal diambil, pencocokan manual dibatalkan.

## Keamanan Android
- Menonaktifkan WebView debugging pada build aplikasi.
- Menonaktifkan pembukaan jendela JavaScript otomatis dan multiple windows.
- Mengaktifkan Safe Browsing pada Android 8.0 ke atas jika didukung WebView.
- Mempertahankan mixed content `NEVER_ALLOW`, third-party cookies nonaktif, akses universal dari file URL nonaktif, dan cleartext traffic nonaktif.
- PIN memakai PBKDF2-HMAC-SHA256, salt acak 16 byte, 150.000 iterasi, hash 256-bit; kompatibilitas PIN lama tetap tersedia untuk migrasi. Pembatasan percobaan PIN 5 kali dengan jeda 30 detik tetap dipertahankan.
- Admin v1.44.2 tidak diubah.

## Pengujian yang dijalankan
- `node --test tests/kebun-sync-invariants.test.js`: 10/10 lulus.
- JavaScript inline diekstrak dari HTML dan diperiksa dengan `node --check`: lulus.

## Batasan yang belum diselesaikan / perlu diuji
- Pantau masih menggunakan Android WebView native dan LocalStorage. Ini **belum setara secara teknologi** dengan Admin yang memakai Capacitor 7 dan IndexedDB. Migrasi tersebut memerlukan perubahan arsitektur Android, bridge file picker/unduhan/print, dan lapisan penyimpanan; tidak aman dilakukan sebagai penggantian konfigurasi sederhana.
- Build APK belum dijalankan di lingkungan ini karena Gradle/Android SDK tidak tersedia.
- Belum ada uji perangkat fisik, uji Cloud produksi, uji pemulihan LocalStorage penuh, atau uji regresi visual seluruh fitur Pabrik.
- Batas 1 jam dihitung dari aktivitas terakhir yang tercatat ketika aplikasi aktif/ditinggalkan. Jika Android mematikan proses tanpa mengirim lifecycle event, timestamp interaksi terakhir tetap menjadi fallback.

## Catatan penting
Versi ini memperbaiki perilaku sinkronisasi dan memperketat beberapa pengaturan WebView, tetapi jangan disebut sebagai migrasi Capacitor/IndexedDB atau sebagai APK teruji sebelum tahap tersebut benar-benar dilakukan.
