# QA v36.0 — Buah Masuk: Auto Cloud + Data Lokal Darurat

## Perubahan lingkup
- Hanya halaman **Buah Masuk/Kebun** yang diubah.
- Halaman **Buah Keluar/Pabrik** tidak diubah.
- PSM SAWIT Admin dan struktur Cloud tidak diubah.

## Model data
- `psm_database_monitor`: snapshot data resmi Cloud (read-only dari Pantau).
- `psm_kebun_emergency_local_v1`: transaksi darurat lokal yang boleh tambah/edit/hapus.
- `psm_kebun_emergency_archive_v1`: salinan lokal darurat yang sudah dicocokkan dengan transaksi Cloud.
- Arsip tidak dimasukkan ke daftar aktif/rekap agar tidak dihitung dua kali.
- Pencocokan hanya ditawarkan untuk kandidat unik dengan tanggal, pemilik, sopir, T1, dan T2 sama; pengguna harus mengonfirmasi. Tidak ada penghapusan otomatis.

## Sinkronisasi
- Tarik Cloud otomatis saat aplikasi dibuka/unlock.
- Pemeriksaan ulang setiap 60 detik ketika halaman terlihat.
- Tarik ulang ketika aplikasi kembali terlihat dan ketika koneksi internet pulih.
- Cloud refresh mengganti snapshot Cloud saja; transaksi lokal darurat dan arsip dipertahankan.
- Jika Cloud gagal atau penyimpanan gagal, snapshot lama dan transaksi lokal dipertahankan.
- Pantau hanya melakukan HTTP GET ke URL Cloud; tidak ada fungsi POST untuk mengirim perubahan.

## Status pembayaran lokal
- Transaksi lokal mempunyai status `BELUM_DIBAYAR` / `SUDAH_DIBAYAR`.
- Status ini hanya tersimpan di perangkat Pantau.
- Status ikut tersimpan dalam arsip pencocokan.

## Pemeriksaan yang dijalankan
- `node --check` untuk seluruh JavaScript inline.
- `node --test tests/kebun-sync-invariants.test.js` untuk invariant pemisahan data, read-only Cloud, archive, dan auto-refresh.

## Belum diuji
- Build APK Android, instalasi, dan perilaku pada perangkat fisik.
- Respons aktual Apps Script/Cloud produksi.
- Uji dua perangkat yang membuka aplikasi bersamaan.
- Sinkronisasi saat aplikasi benar-benar ditutup. Pemeriksaan 60 detik hanya berjalan saat WebView aktif/terlihat; notifikasi push/FCM atau worker Android terpisah diperlukan untuk pemicu saat aplikasi ditutup.
- Printer dan seluruh fungsi halaman Pabrik.

## Sebelum dipakai pada data utama
1. Ekspor backup dari Pantau versi lama.
2. Build APK debug v36.0 dan pasang sebagai uji.
3. Uji tambah/edit/hapus lokal darurat dan force-stop lalu buka kembali.
4. Uji admin menambah/edit/menghapus data, sinkron ke Cloud, lalu pastikan Pantau mengikuti.
5. Cocokkan transaksi lokal, periksa arsip, dan pastikan rekap hanya menghitung satu transaksi.
