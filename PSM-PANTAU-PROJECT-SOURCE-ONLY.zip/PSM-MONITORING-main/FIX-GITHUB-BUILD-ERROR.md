# Perbaikan error GitHub Actions — html2canvas

Error pada screenshot:
`cp: cannot stat 'node_modules/html2canvas/dist/html2canvas.min.js'`

Penyebab: workflow lama mengasumsikan lokasi file vendor dan working directory tertentu. Workflow baru tidak lagi memakai perintah `cp` dengan path yang di-hardcode. Script mencari lokasi package yang benar dari `require.resolve()`, lalu menyalin asset yang ditemukan ke `www/vendor`.

## Langkah di GitHub
1. Upload isi ZIP perbaikan ini ke repository yang sama dan commit ke branch `main`.
2. Buka `.github/workflows`.
3. Hapus workflow lama yang bernama `Build Debug APK from ZIP` (file YAML yang menjalankan langkah `Prepare offline libraries`), atau nonaktifkan workflow tersebut.
4. Buka Actions.
5. Jalankan workflow `Build PSM Pantau APK (fixed dependency setup)`.
6. Periksa hasil build dan unduh artifact `PSM-Pantau-debug-apk`.

Jangan jalankan workflow lama bersamaan dengan workflow baru. Workflow baru memastikan berjalan dari root repository, menginstal dependency, memverifikasi package, menyalin vendor, menjalankan tes, sync Capacitor, lalu membangun APK.

Catatan: build hanya dinyatakan berhasil setelah job GitHub berstatus hijau dan artifact APK muncul.
