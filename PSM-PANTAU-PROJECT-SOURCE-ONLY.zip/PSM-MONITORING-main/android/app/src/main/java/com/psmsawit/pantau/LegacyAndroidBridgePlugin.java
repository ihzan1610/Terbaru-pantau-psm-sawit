package com.psmsawit.pantau;

import android.webkit.WebView;
import com.getcapacitor.CapacitorPlugin;
import com.getcapacitor.Plugin;

/** Installs the v42 JavaScript bridge before Capacitor loads www/index.html. */
@CapacitorPlugin(name = "LegacyAndroidBridge")
public class LegacyAndroidBridgePlugin extends Plugin {
    @Override
    public void load() {
        WebView webView = getBridge().getWebView();
        if (webView == null) throw new IllegalStateException("Capacitor WebView belum tersedia");
        MainActivity activity = (MainActivity) getActivity();
        webView.addJavascriptInterface(activity.new AndroidBridge(), "Android");
        webView.addJavascriptInterface(activity.new AndroidShareBridge(), "AndroidShare");
    }
}
