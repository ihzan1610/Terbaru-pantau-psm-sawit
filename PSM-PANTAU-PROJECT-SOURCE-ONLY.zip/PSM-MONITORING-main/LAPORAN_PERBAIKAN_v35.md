# PSM Sawit Pantau v35.0 — Reliability & Security Hardening

## Tujuan
Memperkuat source Pantau PSM tanpa mengubah alur umum fitur, struktur halaman, atau rumus bisnis yang sudah ada.

## Perubahan

### Android / WebView
- Menonaktifkan mixed content.
- Menolak third-party cookies.
- Menonaktifkan akses file lintas-URL dan akses universal dari URL file.
- Membatasi navigasi halaman utama: halaman asset lokal tetap di WebView; URL web/intent dibuka di aplikasi eksternal; skema lain ditolak.
- Membatasi ukuran file Base64 dan teks yang diteruskan ke Android Bridge.
- Memvalidasi MIME dengan daftar tipe yang didukung.
- Membersihkan file MediaStore yang gagal diselesaikan.
- Menangani pemilihan beberapa URI dari ClipData dan membersihkan callback/WebView saat Activity dihancurkan.
- Menonaktifkan Android Auto Backup (`allowBackup=false`) agar data bisnis lokal tidak otomatis ikut backup perangkat. Backup manual aplikasi tetap tersedia.
- Cleartext HTTP dinonaktifkan; URL Cloud proyek menggunakan HTTPS.

### PIN
- Menambahkan pembatasan 5 percobaan salah dengan jeda 30 detik per sesi.
- PIN lama bermigrasi ke PBKDF2-HMAC-SHA256 (150.000 iterasi, salt acak 16 byte) saat berhasil diverifikasi, jika WebCrypto tersedia.
- PIN baru disimpan sebagai hash PBKDF2; format PIN dibatasi 4–12 angka.
- Kompatibilitas PIN lama dipertahankan saat migrasi tidak tersedia, agar pengguna tidak terkunci tanpa sengaja.

### Penyimpanan dan transaksi
- Menambahkan pembacaan JSON aman untuk database, preferensi, dan draft.
- Validasi bentuk data saat database dimuat.
- Penyimpanan transaksi kebun dan pabrik dilakukan sebelum state aktif/form direset.
- Hapus transaksi, perubahan status pembayaran, tanggal bayar, dan update harga massal menggunakan pola salin → simpan → terapkan.
- Tarik Cloud memvalidasi bentuk data, batas jumlah baris, dan ID duplikat; membuat snapshot data lama sebelum mengganti database; state baru diterapkan hanya jika penyimpanan berhasil.
- Restore pabrik memvalidasi objek, batas jumlah baris, ID kosong/ganda, dan membuat snapshot sebelum mode TIMPA.
- Update harga massal meminta konfirmasi jumlah transaksi yang akan berubah.

## Rumus dan fungsi bisnis
- Tidak mengubah rumus timbang kebun.
- Tidak mengubah rumus sortasi CASH JLY.
- Tidak mengubah aturan sortasi koperasi 3,5%.
- Tidak mengubah perhitungan PPH 0,25% dan potongan Rp30/kg untuk Koperasi JLY/Jalwoy.
- Tidak mengubah alur tab Kebun/Pabrik, laporan, filter, dan format data yang sudah ada.

## Pemeriksaan yang dilakukan
- JavaScript inline: `node --check` lulus.
- AndroidManifest XML: parsing lulus.
- Struktur ZIP: diuji dengan `unzip -t`.
- Pemeriksaan statis konfigurasi keamanan dan fungsi penyimpanan.

## Batas pengujian
- APK belum dibangun karena lingkungan kerja ini tidak memiliki Android SDK/Gradle wrapper.
- Belum diuji pada perangkat Android fisik, printer thermal/RAWBT, dan endpoint Cloud produksi.
- Perlu uji regresi memakai salinan backup data nyata sebelum APK v35 dipasang sebagai aplikasi utama.
- PIN default `1234` tetap menjadi fallback untuk instalasi baru yang belum pernah menetapkan PIN. Segera ubah PIN melalui menu pengaturan setelah instalasi.
- Jika WebCrypto tidak tersedia pada WebView perangkat, migrasi PIN lama ke hash ditunda dan kompatibilitas PIN lama tetap dipakai.
