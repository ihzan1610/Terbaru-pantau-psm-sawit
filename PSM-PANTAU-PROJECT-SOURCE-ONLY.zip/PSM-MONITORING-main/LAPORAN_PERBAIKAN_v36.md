# Laporan Perbaikan Pantau PSM v36.0

## Tujuan
Memisahkan transaksi resmi Cloud dari transaksi darurat lokal pada halaman Buah Masuk, agar perubahan lokal Pantau tidak pernah mengubah Cloud atau aplikasi Admin.

## Yang diubah
1. Memisahkan penyimpanan snapshot Cloud, transaksi darurat lokal, dan arsip transaksi yang telah dicocokkan.
2. Migrasi satu kali dari penyimpanan lama: baris lama yang tersinkron tanpa edit lokal dipertahankan sebagai Cloud; baris lain dipindahkan ke daftar lokal darurat.
3. Cloud menjadi read-only di Pantau. Baris Cloud tidak dapat diedit atau dihapus dari halaman Buah Masuk.
4. Form tambah baru membuat ID lokal unik berawalan `LOC-`; transaksi lokal dapat diedit dan dihapus hanya di perangkat ini.
5. Menambahkan status pembayaran darurat BELUM DIBAYAR/SUDAH DIBAYAR yang hanya lokal.
6. Sinkronisasi GET otomatis saat aplikasi dibuka, ketika kembali terlihat, ketika internet pulih, dan polling 60 detik saat halaman terlihat.
7. Refresh Cloud hanya mengganti snapshot Cloud. Data lokal dan arsip tidak ikut ditimpa.
8. Snapshot Cloud dicadangkan sebelum perubahan baru disimpan. Jika simpan gagal, snapshot sebelumnya tetap dipakai.
9. Pencocokan lokal dengan Cloud hanya menawarkan kandidat unik berdasarkan tanggal, pemilik, sopir, T1, T2; perlu konfirmasi pengguna. Data lokal dipindahkan ke arsip dan tidak masuk hitungan aktif lagi.
10. Menambahkan tampilan daftar arsip pembayaran darurat.
11. Halaman Buah Keluar/Pabrik tidak diubah.

## Batasan
- Tidak mengubah PSM SAWIT Admin, endpoint Cloud, atau rumus bisnis.
- Tidak mengirim data lokal ke Cloud; jalur Pantau ke Cloud hanya GET.
- Auto-refresh saat aplikasi tertutup belum tersedia. Untuk notifikasi perubahan saat tertutup diperlukan FCM/push atau mekanisme Android background terpisah.
- APK belum dibangun dalam lingkungan ini.
