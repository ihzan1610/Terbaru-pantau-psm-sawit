# QA Checklist v39.0

- [x] Pengarsipan lokal tidak lagi dipicu idle satu jam.
- [x] Cloud tetap GET/read-only; tidak ada endpoint write ditambahkan.
- [x] Rekap Pabrik menjumlahkan seluruh hasil filter meski tabel hanya menampilkan 150 baris.
- [x] Netto Pabrik tidak lagi memakai Math.abs untuk input baru.
- [x] Pembayaran memiliki ID batch dan nominal batch untuk cek duplikat pembayaran multi-transaksi.
- [x] Validasi struktur buku pembayaran dan restore diperketat.
- [x] Koreksi tagihan di bawah total pembayaran meminta konfirmasi.
- [x] Footer pembayaran menghitung seluruh baris filter; tampilan tetap maksimum 500 baris.
- [ ] Build APK Gradle di Android CI.
- [ ] Uji fisik HP dan printer thermal.
- [x] XLSX CDN dihapus dari HTML; workflow menyiapkan library XLSX lokal untuk APK.
- [ ] Migrasi IndexedDB bertahap dan uji pemulihan data (rilis terpisah).
- [x] 37/37 tes regresi otomatis lulus.
- [x] Semua 3 blok script inline lolos Node.js syntax check.
- [x] Library XLSX diarahkan ke aset lokal dan disiapkan pada workflow build.
