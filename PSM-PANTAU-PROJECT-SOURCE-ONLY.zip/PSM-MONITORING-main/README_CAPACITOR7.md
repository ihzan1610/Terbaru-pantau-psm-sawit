# PSM Sawit Pantau — Capacitor 7 + IndexedDB v44.1

## Runtime storage
IndexedDB schema 3 is the primary runtime store. The app uses a synchronous compatibility adapter for legacy business functions, while writes are serialized into IndexedDB. Legacy LocalStorage is imported and retained as a recovery snapshot. Full backup/restore uses IndexedDB directly; restore is transactional and preserves the PIN verifier. Per-record SHA-256 checksums and corrupt-record backup are enabled.

## Build
```bash
npm install
npm test
npm run cap:sync
cd android && gradle assembleDebug --no-daemon
```
GitHub Actions runs the same source tests and builds a debug APK. Toolchain: Node 22, JDK 21, Gradle 8.11.1, Android SDK 35, Capacitor 7.6.10.

## Not yet verified
The actual Gradle APK build and physical Android WebView tests are not run in this package creation environment. Android Keystore/AES-GCM encryption is not yet implemented. Back up production data and verify restore before testing an APK over an existing installation.
