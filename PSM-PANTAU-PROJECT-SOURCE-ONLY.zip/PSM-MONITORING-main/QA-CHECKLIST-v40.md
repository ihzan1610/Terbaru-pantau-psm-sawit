# QA Checklist v40.0

- [ ] Ringkasan bulanan hanya menghitung data pada bulan terpilih.
- [ ] Ringkasan tahunan hanya menghitung data pada tahun terpilih.
- [ ] Semua periode tidak membatasi tanggal.
- [ ] Modal diambil dari Buah Masuk pada periode yang sama.
- [ ] Jika data kebun kosong, laba dinyatakan belum dapat dipastikan.
- [ ] Harga SPB dihitung rata-rata tertimbang netto akhir.
- [ ] Sisa tagihan dan umur 7/30 hari ditampilkan sebagai kewajiban, bukan jatuh tempo.
- [ ] Deteksi anomali hanya memberi peringatan dan tidak mengubah data.
- [ ] Perbandingan masuk-keluar menggunakan rentang tanggal yang dipilih.
- [ ] Cloud, pembayaran, Buah Masuk, Pabrik, dan laporan lama tidak berubah.
- [ ] Uji APK, offline, dan perangkat fisik dilakukan sebelum pemakaian produksi.
