const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../android/app/src/main/assets/index.html'), 'utf8');
function between(a,b){ const i=html.indexOf(a), j=html.indexOf(b,i); assert.ok(i>=0&&j>i,`missing block ${a}`); return html.slice(i,j); }

test('official Cloud and emergency local storage use separate keys',()=>{
  assert.match(html,/const KEY_KEBUN="psm_database_monitor"/);
  assert.match(html,/const KEY_KEBUN_LOCAL="psm_kebun_emergency_local_v1"/);
  assert.match(html,/const KEY_KEBUN_ARCHIVE="psm_kebun_emergency_archive_v1"/);
});

test('the visible kebun list is composed of Cloud and active local only; archive is excluded',()=>{
  const b=between('function rebuildKebunView(){','function persistLocalKebun');
  assert.match(b,/cloudKebun\.map/);
  assert.match(b,/localKebun\.map/);
  assert.doesNotMatch(b,/archivedKebun/);
});

test('emergency transaction save persists only to local storage',()=>{
  const b=between('function proses(){','function saveThenReview');
  assert.match(b,/localOnly:true/);
  assert.match(b,/persistLocalKebun\(next\)/);
  assert.doesNotMatch(b,/safeSet\(KEY_KEBUN,/);
});

test('delete action rejects Cloud rows and only filters local rows',()=>{
  const b=between('function hapusData(){','function buildCSV');
  assert.match(b,/d\._source!=='local'/);
  assert.match(b,/localKebun\.filter/);
  assert.doesNotMatch(b,/safeSet\(KEY_KEBUN,/);
});

test('Cloud refresh is read-only GET and never sends local emergency records',()=>{
  const b=between('async function tarikDataCloud','function setKebunCloudStatus');
  assert.match(b,/fetchJsonCloud\(CLOUD_URL,\{redirect:'follow'\}/);
  assert.doesNotMatch(b,/method\s*:\s*['"]POST['"]/i);
  assert.match(b,/safeSet\(KEY_KEBUN,JSON\.stringify\(incoming\)\)/);
  assert.doesNotMatch(b,/localKebun\.map|JSON\.stringify\(dbKebun/);
});

test('Cloud refresh occurs once at app start and never polls or syncs in background',()=>{
  assert.match(html,/function mulaiSistem\(\)[\s\S]*mulaiAutoSyncKebun\(\)/);
  assert.match(html,/return await tarikDataCloud\(true\)/);
  assert.doesNotMatch(html,/setInterval\s*\(/);
  assert.doesNotMatch(html,/handleKebunOnline|handleKebunVisibility/);
});

test('local emergency rows are not auto-archived after idle; user controls reconciliation',()=>{
  const b=between('function arsipkanLokalKedaluwarsa(){','async function mulaiAutoSyncKebun(){');
  assert.match(b,/never move emergency transactions merely because the app was idle/);
  assert.match(b,/return true/);
  assert.doesNotMatch(b,/persistArchiveAndLocal\(\[\],nextArchive\)/);
});

test('manual Cloud reconcile archives matched and unmatched local rows and leaves Cloud authoritative',()=>{
  const b=between('async function cocokkanLokalDenganCloud(){','function bukaArsipLokal');
  assert.match(b,/await tarikDataCloud\(true\)/);
  assert.match(b,/manual-cloud-reconcile-unmatched/);
  assert.match(b,/persistArchiveAndLocal\(\[\],nextArchive\)/);
  assert.match(b,/Daftar aktif setelah proses selesai hanya berisi data resmi Cloud/);
});

test('archive is excluded from active totals and manual reconcile preserves local payment evidence',()=>{
  const b=between('async function cocokkanLokalDenganCloud(){','function bukaArsipLokal');
  assert.match(b,/\.\.\.local/);
  assert.match(b,/nextArchive\.push/);
  assert.match(b,/persistArchiveAndLocal\(\[\],nextArchive\)/);
  assert.doesNotMatch(b,/fetch\([^)]*method/);
});

test('Cloud records are read-only in the form and cannot be edited or deleted',()=>{
  assert.match(html,/function editH\(i\)[\s\S]*_source==='cloud'[\s\S]*Data resmi Cloud hanya bisa dilihat/);
  assert.match(html,/function toggleEdit\(\)[\s\S]*_source!=='local'/);
});
