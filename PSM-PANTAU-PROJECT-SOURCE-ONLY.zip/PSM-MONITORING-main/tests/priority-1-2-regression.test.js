const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../android/app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'../android/app/build.gradle'),'utf8');
const workflow=fs.readFileSync(path.join(__dirname,'../.github/workflows/build-debug-apk.yml'),'utf8');
function block(a,b){const i=html.indexOf(a),j=html.indexOf(b,i);assert.ok(i>=0&&j>i,`missing block ${a}`);return html.slice(i,j)}
test('idle no longer archives emergency local transactions',()=>{const b=block('function arsipkanLokalKedaluwarsa(){','async function mulaiAutoSyncKebun(){');assert.match(b,/never move emergency transactions merely because the app was idle/);assert.doesNotMatch(b,/persistArchiveAndLocal/)});
test('Pabrik table totals use all filtered rows while display is capped at 150',()=>{const b=block('function renderTablePabrik(){','function updateOptNo(){');assert.match(b,/data1\.reduce/);assert.match(b,/data2\.reduce/);assert.match(b,/data3\.reduce/);assert.match(b,/data1\.slice\(0,150\)/);assert.match(b,/data2\.slice\(0,150\)/);assert.match(b,/data3\.slice\(0,150\)/)});
test('Pabrik rejects reversed B1/B2 and does not use absolute difference',()=>{assert.match(html,/validOrder\?Math\.max\(0,b1-b2\):0/);assert.match(html,/if\(data\.b1<=data\.b2\)/);assert.doesNotMatch(block('function hitungNettPabrik','function simpanDataPabrik'),/Math\.abs\(b1-b2\)/)});
test('payment batch identity detects duplicate total amount across split allocations',()=>{assert.match(html,/batchAmount\?\?p\.amount/);assert.match(html,/batchId='BATCH-/);assert.match(html,/batchId,batchAmount:amount/)});
test('payment book rejects duplicate transaction keys and payment IDs',()=>{const b=block('function paySaveBook(next){','function payRecordFor');assert.match(b,/txKeys\.has/);assert.match(b,/paymentIds\.has/);assert.match(b,/Number\.isSafeInteger/)});
test('payment filtered footer sums all rows, not only rendered 500',()=>{const b=block("document.getElementById('pay-count').innerText",'let ownerMap=');assert.match(b,/filtered\.reduce/);assert.match(b,/filtered\.slice\(0,500\)/)});
test('full backup and restore exclude PIN secrets and validate before replacement',()=>{assert.match(html,/PSM_PANTAU_FULL_BACKUP/);assert.match(html,/psm_pin_secure_monitor/);assert.match(html,/Pulihkan '\+entries\.length/);assert.match(html,/Data Cloud di server tidak diubah/)});
test('XLSX is loaded locally and build workflow packages it offline',()=>{assert.match(html,/<script src="vendor\/xlsx\.full\.min\.js"><\/script>/);assert.match(fs.readFileSync(path.join(__dirname,'..','package.json'),'utf8'),/\"xlsx\": \"0\.18\.5\"/);assert.match(fs.readFileSync(path.join(__dirname,'..','scripts','copy-vendor-assets.js'),'utf8'),/xlsx\/dist\/xlsx\.full\.min\.js/)});
test('version metadata bumped to v44',()=>{assert.match(gradle,/versionCode 46/);assert.match(gradle,/versionName '44\.2-stability'/)});

test('unallocated payments can be manually allocated to an eligible bill',()=>{assert.match(html,/function payAllocateUnallocated\(index\)/);assert.match(html,/PAYMENT_ALLOCATE/);assert.match(html,/ALOKASIKAN/)});
test('local backup reminders and bounded audit trail are available',()=>{assert.match(html,/function cekReminderBackupPantau\(\)/);assert.match(html,/function catatAuditPantau\(/);assert.match(html,/rows\.slice\(-1000\)/);assert.match(html,/cekReminderBackupPantau\(\)/)});
test('Pabrik changes write audit events after successful local persistence',()=>{assert.match(html,/UPDATE_HARGA_MASSAL/);assert.match(html,/STATUS_BAYAR_PABRIK/);assert.match(html,/EDIT_BUAH_KELUAR/)});
