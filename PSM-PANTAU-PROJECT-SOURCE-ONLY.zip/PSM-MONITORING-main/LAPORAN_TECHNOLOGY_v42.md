# PSM Pantau v42.0 — Tahap Migrasi Data Terverifikasi

## Perubahan pada v42
- IndexedDB durability database dinaikkan ke schema v2 dengan object store `kv` dan `meta`.
- Setiap nilai `psm_` non-PIN yang disalin ke IndexedDB memiliki SHA-256 checksum.
- Migrasi awal hanya mengimpor kunci LocalStorage yang belum ada di IndexedDB; data mirror yang sudah ada tidak ditimpa diam-diam.
- Setelah proses impor, semua record mirror diverifikasi ulang sebelum metadata `migration_v42` ditulis sebagai selesai.
- Status kesehatan menyediakan `readyPromise`, `flush()`, dan `check()` yang mengembalikan jumlah data, jumlah terverifikasi, jumlah gagal, serta kunci yang bermasalah.
- Jika IndexedDB/WebCrypto tidak tersedia atau checksum gagal, kegagalan ditampilkan pada status kesehatan dan aplikasi tidak menyatakan migrasi berhasil.
- Kunci PIN tetap dikecualikan dari mirror.
- Versi Android dinaikkan menjadi versionCode 42 / versionName 42.0.

## Perlindungan kompatibilitas
- LocalStorage masih menjadi sumber runtime utama karena banyak fitur lama menggunakan API sinkron `localStorage.getItem/setItem`.
- Tidak ada auto-restore dari mirror ke LocalStorage; ini mencegah penghapusan yang disengaja dibatalkan diam-diam.
- Tidak ada perubahan hak akses Cloud; Pantau tetap hanya mengambil data Cloud.
- Package ID Android tetap `com.psmsawit.pantau`.

## Status migrasi teknologi yang jujur
Belum dilakukan pada rilis ini:
1. Migrasi runtime database utama dari LocalStorage ke IndexedDB.
2. Porting aplikasi ke Capacitor 7 dan penggantian MainActivity/AndroidBridge.
3. Enkripsi seluruh data transaksi menggunakan kunci Android Keystore.

Tiga perubahan tersebut membutuhkan migrasi asinkron di semua modul dan pengujian perangkat nyata. Menerapkannya sekaligus tanpa build dan pengujian Android berisiko merusak data atau fitur cetak/pemilih file. v42 ini menyiapkan inventaris dan verifikasi migrasi yang lebih kuat, bukan mengklaim migrasi penuh selesai.

## QA
- `node --test tests/*.test.js`: 55/55 lulus.
- Seluruh inline JavaScript: `node --check` lulus (4 blok digabung untuk pemeriksaan sintaks).
- AndroidManifest XML valid.
- APK belum dibangun atau diuji pada perangkat fisik di lingkungan ini.
