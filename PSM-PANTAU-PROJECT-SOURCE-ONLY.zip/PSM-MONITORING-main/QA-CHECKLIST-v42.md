# QA Checklist v42

- [x] Existing regression tests: 55/55 pass
- [x] Inline JavaScript syntax check
- [x] AndroidManifest XML parse
- [x] IndexedDB schema v2 + metadata store
- [x] SHA-256 integrity verification of mirror records
- [x] PIN keys excluded from mirror
- [x] No silent overwrite of existing mirror rows during legacy import
- [x] Cloud access model unchanged (read-only)
- [ ] Full IndexedDB primary-store migration
- [ ] Capacitor 7 native bridge migration
- [ ] Android Keystore encryption for local business data
- [ ] Gradle APK build
- [ ] Real-device data migration/rollback test
- [ ] RAWBT printer and file picker regression on device
