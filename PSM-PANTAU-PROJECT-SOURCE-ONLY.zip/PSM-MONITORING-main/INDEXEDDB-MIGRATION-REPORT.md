# IndexedDB runtime hardening — v44.1 checkpoint

## Implemented
- IndexedDB schema 3 remains the runtime primary store behind a synchronous compatibility adapter.
- Legacy LocalStorage values are imported at first launch; LocalStorage is retained as a recovery snapshot and is not cleared automatically.
- Per-record SHA-256 verification and corrupt-record backup remain active.
- Full backup now enumerates the IndexedDB adapter cache (not `Object.keys(localStorage)`, which is incompatible with a custom Storage adapter).
- Full restore validates input, commits a complete replacement in one IndexedDB transaction, and only updates the in-memory cache after commit.
- Restore preserves the PIN verifier and non-application keys; it replaces only ordinary `psm_` application data.
- Failed writes are tracked by key and remain visible to the health check until that key is successfully written again.
- Persistent-origin storage is requested where supported; `visibilitychange`, `freeze`, `pagehide`, and `beforeunload` trigger flush attempts.
- Capacitor web source and Android fallback asset are kept byte-identical.

## Verification
- Node regression suite: 65/65 passing in the local environment.
- JSON/Gradle metadata and Android manifest checks: pending final packaging check.
- Android WebView device test and actual APK build: not performed here.

## Safety notes
- No automatic deletion of the old LocalStorage recovery snapshot.
- No Cloud writes; Cloud remains GET-only.
- This is not encryption-at-rest. Android Keystore/AES-GCM remains a separate required security phase.
- Do not install over production data until a backup has been exported and successfully restored in a test installation.
