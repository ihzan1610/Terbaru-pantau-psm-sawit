# PSM Pantau v41.0 — Penguatan Teknologi & Keamanan

## Perubahan pada rilis ini
- Menghapus fallback PIN 1234 sebagai mekanisme login. Jika belum ada PIN aman, layar pertama meminta PIN baru 6–12 digit.
- PBKDF2-HMAC-SHA256 dengan salt acak 16 byte dan 210.000 iterasi untuk PIN baru.
- PIN lama yang eksplisit (bukan 1234) dapat diverifikasi lalu dimigrasikan ke hash baru.
- Menambahkan IndexedDB durability mirror untuk kunci `psm_`, kecuali PIN. Data LocalStorage lama disalin satu kali dan penulisan berikutnya dicerminkan secara asynchronous.
- Mempertahankan LocalStorage sebagai sumber baca/tulis sinkron demi kompatibilitas fitur.
- Menambahkan regresi otomatis pada workflow build serta validasi keberadaan library offline.
- Android versionCode 41 / versionName 41.0.

## Batasan yang belum selesai
- Belum migrasi ke Capacitor 7. Pantau masih memakai Android WebView native dan AndroidBridge untuk file serta RAWBT. Migrasi perlu porting bridge dan pengujian ulang.
- IndexedDB saat ini merupakan mirror ketahanan, belum menjadi database utama. Tidak ada auto-restore dari mirror agar penghapusan data yang disengaja tidak dibatalkan diam-diam.
- Isi transaksi lokal belum dienkripsi menyeluruh. PBKDF2 melindungi verifier PIN, bukan seluruh data transaksi.
- HTML2Canvas/XLSX diambil pada saat workflow build; aset di APK hasil build menjadi lokal/offline. Placeholder di source ZIP akan diganti oleh workflow.
- APK belum dibangun dan diuji di perangkat fisik dalam lingkungan ini.

## Migrasi penuh yang direkomendasikan sebagai tahap berikutnya
1. Port Android ke Capacitor 7 dengan menjaga package ID `com.psmsawit.pantau` dan memindahkan fungsi AndroidBridge menjadi plugin/bridge yang teruji.
2. Pindahkan seluruh entitas Buah Masuk, arsip, pembayaran, Pabrik, tarif, dan audit ke IndexedDB dengan migrasi satu kali, checksum/jumlah baris, dan rollback.
3. Setelah verifikasi, jadikan IndexedDB sumber utama dan LocalStorage hanya mirror preferensi/status kecil.
4. Tambahkan enkripsi data sensitif dengan kunci yang disimpan di Android Keystore, tanpa mengandalkan PIN sebagai kunci enkripsi langsung.
