# Pantau PSM v38.0 — Smart Payment Control

## Fokus
Menambahkan halaman Pembayaran pribadi Pantau tanpa mengubah Admin, data Cloud, rumus timbang, maupun halaman Buah Keluar.

## Navigasi
Urutan menu utama: 1) Buah Masuk, 2) Pembayaran, 3) Buah Keluar. Pembayaran adalah halaman tersendiri dan sumber tagihannya berasal dari Buah Masuk.

## Fitur pembayaran
- Dashboard total tagihan, sudah dibayar, sisa, dan jumlah pemilik tertunggak.
- Daftar transaksi dengan filter pemilik/sopir/ID, rentang tanggal, status, dan metode.
- Nilai tagihan awal otomatis dari `bersih` (fallback `kotor`, lalu `n2 × price`); nilai dapat dikoreksi manual dengan alasan dan jejak audit.
- Pembayaran sebagian/bertahap dengan metode Transfer, Cash Timbangan, Cash Rumah, dan Cash Lainnya.
- Pembayaran multi-transaksi: pengguna memilih transaksi atau meminta aplikasi memilih maksimal 10 transaksi tertua. Alokasi dimulai dari transaksi tertua dan tetap memerlukan konfirmasi penyimpanan.
- Peringatan duplikasi berdasarkan tanggal, metode, nominal, dan referensi.
- Deteksi tagihan lama, kelebihan pembayaran, transaksi arsip yang perlu ditinjau, dan pembayaran belum dialokasikan.
- Riwayat pembayaran, ekspor CSV, backup JSON, dan restore dengan validasi skema serta konfirmasi penggantian.
- Migrasi status darurat lama `SUDAH_DIBAYAR` menjadi bukti pembayaran lokal dengan metode diberi label `METODE TIDAK DICATAT`.

## Isolasi dan keselamatan data
- Buku pembayaran memakai key LocalStorage terpisah `psm_private_payment_book_v1`.
- Tidak ada fungsi pembayaran yang memanggil endpoint Cloud atau mengirim POST.
- Tidak menambah menu/fitur pembayaran pada Admin.
- Pencocokan lokal-ke-Cloud mempertahankan keterkaitan riwayat melalui ID lokal dan `matchedCloudId`.
- Data timbang Cloud tetap read-only. Buah Keluar tidak dimodifikasi selain perubahan urutan navigasi.

## Batasan yang diketahui
- Implementasi ini masih menggunakan WebView native dan LocalStorage; migrasi Capacitor 7/IndexedDB belum dilakukan.
- Bukti foto kuitansi/transfer belum disertakan pada rilis ini; kolom referensi dan catatan tersedia. Fitur foto sengaja ditunda agar penyimpanan tetap ringan dan perlu rancangan kompresi/batas ukuran.
- Backup pembayaran adalah ekspor JSON manual; tidak ada proses backup otomatis di latar belakang.
- APK belum dibangun atau diuji pada perangkat fisik di lingkungan ini.

## Tambahan perbaikan Buah Masuk (v38.0)

- Mempertahankan pemisahan Cloud resmi, transaksi darurat lokal, dan arsip lokal; seluruh tes invariant lama tetap dijalankan.
- Menyamakan target nota gambar Buah Masuk dengan Admin: lebar 500 px, html2canvas disiapkan sebagai aset lokal saat workflow APK berjalan, skala capture 3x.
- Menambahkan pengaturan nota lokal: nama penimbang, logo PNG/JPG (maks. 700 KB), tampil/sembunyi logo gambar, dan aktif/nonaktif bitmap logo thermal.
- Jalur thermal satu transaksi kini memakai format slip individual; beberapa transaksi tetap memakai format rekap.
- Jalur cetak thermal memakai tipe konten yang sama dengan preview; bitmap logo diambil dari pengaturan yang tersimpan.
- Menyesuaikan metadata Android menjadi versionCode 38 / versionName 38.0.
- Buah Keluar/Pabrik dan Pembayaran tidak diubah.

QA otomatis: `node --test tests/*.test.js` (21 tes lulus); pemeriksaan sintaks JavaScript inline `node --check` lulus. Cetak fisik dan APK belum diuji pada perangkat/printer nyata.
