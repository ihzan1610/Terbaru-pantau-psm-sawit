# Checklist QA Pantau PSM v35

## Sebelum pemasangan
- [ ] Ekspor backup Kebun dan Pabrik.
- [ ] Simpan ZIP source versi sebelumnya.
- [ ] Build APK v35 melalui Android Studio/GitHub Actions.

## Uji data
- [ ] Buka aplikasi dengan database kosong.
- [ ] Buka aplikasi dengan database lama.
- [ ] Tambah/edit/hapus transaksi kebun.
- [ ] Tambah/edit/hapus transaksi pabrik.
- [ ] Matikan/force-stop aplikasi setelah transaksi disimpan, lalu buka ulang.
- [ ] Uji saat penyimpanan perangkat hampir penuh (gunakan data uji, bukan data utama).
- [ ] Tarik Cloud: data valid, data kosong, ID duplikat, dan koneksi terputus.
- [ ] Restore TIMPA dan GABUNG dengan data uji; cek backup sebelum TIMPA.
- [ ] Uji update harga massal dan pastikan jumlah data yang berubah benar.

## Uji Android
- [ ] Ubah PIN; tutup dan buka aplikasi; pastikan PIN baru bekerja.
- [ ] Uji 5 PIN salah dan jeda 30 detik.
- [ ] Uji file chooser JSON/CSV/XLSX.
- [ ] Simpan gambar/CSV/JSON ke Download.
- [ ] Uji tautan WhatsApp dan tautan web eksternal.
- [ ] Uji Android Back pada form, modal, dan antar-tab.

## Uji fungsi bisnis
- [ ] Cocokkan perhitungan kebun dengan transaksi contoh.
- [ ] Cocokkan sortasi CASH JLY.
- [ ] Cocokkan sortasi koperasi 3,5% sesuai aturan yang saat ini ada di source.
- [ ] Cocokkan potongan Koperasi JLY/Jalwoy.
- [ ] Cocokkan rekap, pembayaran, laba, dan ekspor.
- [ ] Uji printer thermal/RAWBT pada perangkat sebenarnya.
