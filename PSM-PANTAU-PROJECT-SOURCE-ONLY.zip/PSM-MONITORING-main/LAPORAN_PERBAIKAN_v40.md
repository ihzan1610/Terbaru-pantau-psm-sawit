# PSM Pantau v40.0 — Prioritas 3 (Analisis Usaha Pintar)

## Fitur tambahan
- Ringkasan usaha bulanan, tahunan, dan semua periode berdasarkan transaksi Buah Keluar asal TIMBANGAN.
- Modal periode diambil dari data Buah Masuk pada tanggal yang sama; bila tidak ada data kebun yang cocok, aplikasi menyatakan estimasi laba belum dapat dipastikan.
- Perbandingan harga jual rata-rata tertimbang per SPB (harga × netto akhir), disertai volume dan jumlah rit.
- Panel kebutuhan kas pembayaran yang merangkum sisa tagihan, bagian berumur >=7 hari, dan >=30 hari. Ini adalah kewajiban berjalan berdasarkan umur transaksi, bukan prediksi jatuh tempo.
- Pemeriksaan anomali dasar: tanggal, B1/B2, harga kosong, sopir kosong, netto tidak sesuai B1-B2, netto akhir lebih besar dari netto, serta selisih masuk-keluar pada rentang tanggal yang dipilih.
- Analisis hanya membaca data; tidak mengubah transaksi, tarif, pembayaran, atau data Cloud.

## Batasan yang disengaja
- Laba bulanan/tahunan ditampilkan sebagai estimasi hanya bila ada data Buah Masuk untuk periode yang sama.
- Selisih masuk-keluar bukan otomatis disebut susut; restan, beda periode, dan transaksi yang belum dicatat harus diperiksa.
- Kebutuhan kas bukan proyeksi tanggal pembayaran karena data jatuh tempo belum tersedia.
- Tidak ada migrasi database atau perubahan rumus bisnis dalam tahap ini.

## QA
- Pemeriksaan sintaks JavaScript inline.
- Tes regresi prioritas 1 dan 2 tetap dijalankan.
- Tes baru untuk panel analisis, perbandingan SPB, estimasi kas, dan deteksi anomali.
- Build APK dan uji perangkat fisik tetap memerlukan Android SDK/Gradle dan perangkat pengguna.
