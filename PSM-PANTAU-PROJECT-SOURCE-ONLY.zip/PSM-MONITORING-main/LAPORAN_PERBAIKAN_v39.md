# PSM Pantau v39.0 — Prioritas 1 & 2

- Menonaktifkan pengarsipan otomatis transaksi lokal darurat hanya karena aplikasi tidak aktif satu jam. Pengarsipan tetap melalui rekonsiliasi manual.
- Memperbaiki subtotal tiga tabel Pabrik agar menjumlahkan seluruh data hasil filter, sementara tampilan baris tetap dibatasi 150 untuk performa.
- Menambahkan validasi B1 harus lebih besar daripada B2 pada input baru/perubahan; rumus netto tidak lagi menggunakan nilai absolut untuk menyamarkan urutan berat terbalik.
- Memperkuat integritas buku pembayaran: validasi struktur, ID transaksi, ID pembayaran, nilai rupiah, dan restore.
- Menambahkan identitas batch pembayaran dan nominal batch untuk deteksi duplikat ketika satu pembayaran dialokasikan ke beberapa transaksi.
- Meminta konfirmasi jika koreksi tagihan membuat pembayaran yang sudah masuk menjadi saldo lebih.
- Memperbaiki total footer tabel Pembayaran agar menghitung seluruh hasil filter, bukan hanya 500 baris yang ditampilkan.
- Mempertahankan kunci LocalStorage dan bentuk data lama agar kompatibilitas data tetap terjaga.

## Batasan QA

Belum dilakukan build Gradle/APK dan uji printer/HP fisik. Migrasi IndexedDB sengaja tidak dilakukan dalam patch ini karena memerlukan migrasi data atomik dan uji pemulihan khusus; pemaksaan migrasi sekaligus berisiko pada data lokal pengguna. Library XLSX kini diarahkan ke aset lokal dan workflow build menyalin paket XLSX serta html2canvas ke APK; file vendor hasil npm disiapkan saat workflow berjalan, bukan disertakan sebagai placeholder di ZIP sumber.

## Hasil pemeriksaan otomatis

- 37/37 tes regresi otomatis lulus (termasuk tes lama yang disesuaikan dengan aturan baru dan tes tambahan v39).
- Seluruh 3 blok script inline lolos `node --check`.
- Pemeriksaan XML AndroidManifest dan struktur Gradle dilakukan terpisah.
- Tidak ada perubahan pada PSM Admin.
- Tidak ada penambahan operasi tulis ke Cloud.
