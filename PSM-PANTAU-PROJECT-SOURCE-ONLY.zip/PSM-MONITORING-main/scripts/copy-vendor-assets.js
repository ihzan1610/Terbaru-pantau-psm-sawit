const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const out = path.join(root, 'www', 'vendor');
fs.mkdirSync(out, { recursive: true });

function findPackageFile(packageName, preferredFiles) {
  let packageEntry;
  try {
    packageEntry = require.resolve(packageName, { paths: [root] });
  } catch (error) {
    throw new Error(`Dependency "${packageName}" tidak ditemukan. Pastikan npm install dijalankan di folder repository: ${error.message}`);
  }

  let dir = path.dirname(packageEntry);
  for (let depth = 0; depth < 5; depth++) {
    for (const file of preferredFiles) {
      const candidate = path.join(dir, file);
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }

  // Last-resort search within the installed package directory.
  const packageRoot = path.dirname(packageEntry);
  const wanted = new Set(preferredFiles);
  function walk(folder, depth) {
    if (depth > 5) return null;
    for (const item of fs.readdirSync(folder, { withFileTypes: true })) {
      if (item.name === 'node_modules' || item.name.startsWith('.')) continue;
      const full = path.join(folder, item.name);
      if (item.isFile() && wanted.has(item.name)) return full;
      if (item.isDirectory()) {
        const found = walk(full, depth + 1);
        if (found) return found;
      }
    }
    return null;
  }
  const found = walk(packageRoot, 0);
  if (found) return found;
  throw new Error(`File vendor tidak ditemukan untuk ${packageName}. Entry package: ${packageEntry}`);
}

const assets = [
  {
    packageName: 'html2canvas',
    candidates: ['html2canvas.min.js', 'html2canvas.js'],
    target: 'html2canvas.min.js'
  },
  {
    packageName: 'xlsx',
    candidates: ['xlsx.full.min.js', 'xlsx.full.js'],
    target: 'xlsx.full.min.js'
  }
];

for (const asset of assets) {
  const from = findPackageFile(asset.packageName, asset.candidates);
  fs.copyFileSync(from, path.join(out, asset.target));
  console.log(`Copied ${asset.packageName}: ${from} -> www/vendor/${asset.target}`);
}
