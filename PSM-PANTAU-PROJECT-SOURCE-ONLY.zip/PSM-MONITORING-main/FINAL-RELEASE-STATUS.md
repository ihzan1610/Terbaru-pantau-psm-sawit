# PSM Sawit Pantau — v44.2 Stability Checkpoint

## Focus
This checkpoint prioritizes application behavior, data preservation, and build reproducibility rather than adopting a particular technology for its own sake.

## Included application areas
- Buah Masuk and local emergency transaction handling
- Cloud read-only GET and local/Cloud reconciliation
- Pembayaran: partial and batch allocations, payment methods, history, audit, backup/restore
- Buah Keluar/Pabrik calculation and reporting safeguards
- Ongkos Langsir and Gaji Langsir summaries
- Search/filter/reporting and local export/print/image flows
- PIN and IndexedDB-backed local persistence with migration and integrity checks

## Build
Run `npm install`, `npm test`, then `npm run android:debug`.
The GitHub Actions workflow builds `android/app/build/outputs/apk/debug/app-debug.apk`.

## Verification in this environment
- Regression suite: 69/69 passed.
- Inline JavaScript syntax: passed.
- Android manifest and FileProvider XML: valid.
- JSON configuration: valid.
- ZIP integrity: passed.
- Capacitor/Gradle APK build and physical Android device test: NOT performed here.

## Important
This is a source release checkpoint, not a claim of device-certified final production APK.
Before replacing an app containing production data, export a backup and verify restore on a separate test installation. Do not uninstall the current app until recovery has been proven.
