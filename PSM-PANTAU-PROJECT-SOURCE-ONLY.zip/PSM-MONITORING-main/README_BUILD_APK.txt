PSM SAWIT PANTAU v44.2 — BUILD APK

GitHub:
1. Ekstrak ZIP.
2. Upload semua isi folder PSM-MONITORING-main ke repository.
3. Push ke branch main atau master.
4. Buka Actions dan jalankan Build Capacitor 7 APK.
5. Setelah sukses, unduh artifact PSM-Sawit-Pantau-capacitor7-debug-apk.

Build lokal:
  npm install
  npm test
  npm run android:debug

Build lokal memerlukan Node.js 22, JDK 21, Android SDK Platform 35 dan Gradle 8.11.1.
APK debug bukan APK release yang ditandatangani untuk distribusi.

Sebelum menguji di atas aplikasi berisi data penting, ekspor backup dan uji restore pada instalasi terpisah.
