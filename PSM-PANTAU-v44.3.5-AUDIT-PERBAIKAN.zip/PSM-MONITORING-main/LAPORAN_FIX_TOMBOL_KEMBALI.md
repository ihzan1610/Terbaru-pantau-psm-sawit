# Laporan Perbaikan Tombol Kembali – PSM Pantau v44.3

## Gejala yang dilaporkan
Tombol kembali hanya berfungsi di menu utama. Setelah membuka cetak/preview, rekap, pembayaran, pengaturan, backup, atau jendela data lainnya, tombol kembali Android tidak selalu menutup layar yang sedang terbuka atau kembali ke halaman sebelumnya.

## Temuan kode
- `MainActivity.onBackPressed()` memanggil `window.handleAndroidBack()`.
- Sebelumnya `window.handleAndroidBack` hanya berupa fallback sederhana dan tidak memakai seluruh logika navigasi utama `handleNativeBack`.
- Handler lama tidak menangani semua overlay, termasuk modal khusus `pantau-langsir-modal`, dan tidak memprioritaskan dialog yang paling atas.
- Jalur `popstate` browser juga memakai handler yang berbeda.

## Perubahan
1. Menyatukan tombol kembali Android dan navigasi browser ke `window.handleAndroidBack`.
2. Mendeteksi semua overlay yang sedang terlihat (`.modal-overlay` dan `.langsir-modal`).
3. Menutup overlay teratas berdasarkan z-index dan urutan DOM, sehingga modal bertumpuk ditutup satu per satu.
4. Menambahkan penanganan khusus untuk dialog Ongkos/Gaji Langsir dan dialog pembayaran.
5. Memanggil `tutupModal()` untuk dialog standar agar efek samping penutupan (misalnya refresh tabel) tetap dijalankan.
6. Memperbaiki `handleNativeBack()` agar membersihkan referensi modal yang sudah tertutup dan kembali dari tab Buah Keluar/Pembayaran.
7. Menyamakan aset `www/index.html` dan Android `assets/index.html`.

## Validasi
- `npm test`: 100 tes lulus, 0 gagal.
- Tes regresi mencakup handler Android, overlay teratas, halaman Buah Keluar/Pembayaran, dan kesamaan aset HTML.
- APK belum dibangun dan tombol fisik Android belum diuji pada perangkat. Uji akhir diperlukan setelah APK dibuat dan dipasang.
