# Wheel Date Picker untuk Filter Pantau PSM v44.3

## Permintaan
Untuk filter tanggal di halaman Buah Masuk (halaman utama) dan halaman Pembayaran, tanggal terpilih tampil ringkas sebagai satu teks, misalnya `08 Agustus 2026`. Tanggal/bulan/tahun tetangga hanya terlihat saat pengguna membuka dan menggulir pemilih tanggal.

## Implementasi
- Mengganti tampilan native date filter `f-start`, `f-end`, `pay-start`, dan `pay-end` dengan tombol tanggal ringkas.
- Saat tombol disentuh, membuka pemilih model roda gulir tiga kolom: tanggal, bulan, tahun.
- Item sebelum/sesudah pilihan terlihat di dalam picker saat dibuka; posisi terpilih berada di tengah dengan efek scroll-snap dan fade.
- Saat picker ditutup, kolom roda tidak terlihat; hanya tanggal terpilih yang ditampilkan.
- Tombol Batal tidak mengubah filter.
- Tombol Pilih tanggal memperbarui input tanggal internal dan memicu event `change`, sehingga fungsi filter lama tetap digunakan.
- Filter kosong tetap kosong sampai pengguna memilih tanggal.
- Tanggal disimpan sebagai `YYYY-MM-DD` kalender lokal, tanpa konversi UTC.
- Tanggal transaksi, tanggal pembayaran, filter Pabrik, dan filter Langsir tidak diubah.

## Validasi
- `npm test`: 117 tes lulus, 0 gagal.
- Enam tes khusus wheel picker lulus.
- File HTML web dan Android packaged asset identik.
- Build APK dan uji interaksi pada perangkat Android belum dilakukan.
