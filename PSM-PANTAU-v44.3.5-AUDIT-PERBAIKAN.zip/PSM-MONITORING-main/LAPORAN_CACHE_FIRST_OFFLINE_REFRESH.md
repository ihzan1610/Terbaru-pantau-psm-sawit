# Cache-First dan Automatic Cloud Refresh – Pantau PSM

## Perilaku yang diminta
Saat aplikasi dibuka, data Cloud terakhir yang tersimpan di perangkat harus langsung terlihat. Proses tarik data Cloud berjalan setelah tampilan awal, tanpa mengosongkan daftar. Saat offline, data terakhir tetap tersedia. Saat koneksi kembali atau aplikasi kembali ke foreground, aplikasi mencoba mengambil data terbaru.

## Temuan kode sebelumnya
- `mulaiSistem()` memanggil `mulaiAplikasiKebun()` lalu `mulaiAutoSyncKebun()`.
- `mulaiAplikasiKebun()` sudah merender `cloudKebun` dari penyimpanan lokal sebelum fetch.
- `tarikDataCloud()` tidak menghapus cache sebelum fetch, tetapi belum punya snapshot last-good khusus untuk pemulihan jika key utama kosong/rusak.
- Respons Cloud kosong atau `count` yang tidak cocok dapat berisiko dianggap sebagai snapshot baru jika tidak divalidasi.

## Perubahan
1. Menambahkan `psm_database_monitor_last_good_v1` sebagai cadangan snapshot Cloud terakhir yang valid.
2. Saat startup, jika cache utama kosong, aplikasi mencoba memulihkan dari last-good snapshot atau snapshot backup sebelumnya.
3. Data cache ditampilkan lebih dahulu sebelum permintaan Cloud dimulai.
4. Permintaan Cloud tidak mengosongkan tabel maupun variabel data yang sedang tampil.
5. Validasi respons: bentuk `{data:[]}`, batas jumlah data, kecocokan `count` jika disediakan, object baris valid, ID tidak kosong dan tidak ganda.
6. Respons kosong ditolak jika cache perangkat masih berisi transaksi; cache lama dipertahankan.
7. Snapshot lama disimpan sebagai last-good sebelum cache utama diganti. Setelah cache utama berhasil ditulis, snapshot last-good diperbarui.
8. Saat offline, status menjelaskan bahwa data terakhir tetap ditampilkan.
9. Saat perangkat kembali online atau aplikasi kembali ke foreground, satu refresh otomatis dicoba. Tidak ada polling berkala atau sync background ketika aplikasi tertutup.
10. Data lokal darurat dan arsip tetap terpisah; refresh otomatis tidak menghapus atau mengarsipkannya.

## Validasi
- `npm test`: 111 tes lulus, 0 gagal.
- Aset `www/index.html` dan Android packaged asset identik.
- Tes perangkat fisik dan build APK belum dilakukan di lingkungan ini.
