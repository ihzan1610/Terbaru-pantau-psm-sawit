# Perbaikan Keyboard Input dan PIN – Pantau PSM

## Perubahan
- Semua field teks, pencarian, dan textarea diberi `autocorrect=off`, `autocapitalize=off`, dan `spellcheck=false` agar aplikasi tidak mengubah ejaan/kapitalisasi yang sedang diketik.
- Tidak ada handler baru yang memotong atau mencegat `keydown`, `beforeinput`, Backspace, Delete, atau komposisi IME. Penghapusan karakter tetap diserahkan ke keyboard Android/WebView.
- Field angka yang belum memiliki `inputmode` diberi mode `numeric`; field angka desimal memakai `decimal`.
- Field PIN masuk, PIN baru, konfirmasi PIN, PIN lama, dan PIN baru di pengaturan menggunakan `type=tel` + `inputmode=numeric` + pola digit agar Android lebih konsisten menampilkan keypad angka.
- Tampilan PIN tetap disamarkan menggunakan CSS `-webkit-text-security: disc`.
- Perubahan diterapkan pada HTML web dan aset HTML Android.

## Validasi
- `npm test`: 131 tes lulus, 0 gagal.
- Semua 6 blok JavaScript inline lolos `node --check`.
- Aset web dan Android identik.
- APK belum dibangun dan pengujian keyboard fisik/Gboard di HP belum dilakukan.

## Batasan
Perilaku Backspace yang berasal dari Gboard, versi Android, atau WebView harus dikonfirmasi di perangkat. Source tidak memasang handler yang mengambil alih tombol hapus karena hal itu berisiko membuat karakter terhapus ganda atau merusak IME.
