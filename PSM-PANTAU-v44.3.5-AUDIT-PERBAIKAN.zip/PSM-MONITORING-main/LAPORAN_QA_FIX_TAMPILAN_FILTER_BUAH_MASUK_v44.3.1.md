# Laporan Perbaikan & QA – Pantau PSM v44.3.1

## Temuan utama dari screenshot
Dua input tanggal pada filter halaman Buah Masuk (`f-start` dan `f-end`) memiliki atribut `onchange` yang terpotong. Potongan `style="display:none"` keluar dari nilai atribut, sedangkan ekor handler `clearSelection();renderLiveTable()` tertinggal sebagai teks setelah elemen. Browser akhirnya menampilkan kode JavaScript mentah dan membangun susunan filter yang salah.

## Perbaikan
- Menulis ulang kedua elemen input tanggal dengan atribut `onchange` lengkap dan tertutup.
- Memastikan input tanggal tetap tersembunyi untuk pemilih tanggal roda yang sudah ada.
- Memastikan tombol `Tanggal awal` dan `Tanggal akhir` masing-masing memanggil target picker yang benar.
- Memastikan dua pencarian teks dan dua kontrol tanggal tetap menjadi empat anak langsung dari `.filter-grid`.
- Menyamakan `www/index.html` dengan HTML yang dipaketkan Android (`android/app/src/main/assets/index.html`).
- Menambahkan tes regresi khusus agar potongan JavaScript tidak bisa muncul lagi sebagai teks di filter Buah Masuk.

## Hasil pemeriksaan
- `npm test`: **135 tes lulus, 0 gagal**.
- 6 blok JavaScript inline: **lulus pemeriksaan sintaks Node.js**.
- Pemeriksaan struktur DOM HTML: filter berisi tepat 2 kolom pencarian + 2 pemilih tanggal.
- Pemeriksaan teks yang terlihat: tidak ada `clearSelection()` atau `renderLiveTable()` yang bocor menjadi teks halaman.
- Pemeriksaan ID HTML: tidak ditemukan ID duplikat.
- HTML web dan Android: identik.

## Pemeriksaan yang belum dapat diselesaikan di lingkungan ini
- Render screenshot Chromium headless gagal dijalankan karena proses GPU Chromium pada lingkungan pengujian berhenti sebelum menghasilkan screenshot. Jadi inspeksi visual akhir pada browser belum bisa diklaim lulus.
- Build APK berhenti pada tahap penyalinan aset karena dependensi npm `html2canvas` belum terpasang di lingkungan kerja (`node_modules` tidak tersedia). Ini bukan kegagalan tes aplikasi; APK baru belum dihasilkan.
- Tes langsung pada perangkat Android/Gboard tetap diperlukan untuk konfirmasi visual dan interaksi akhir.

## File utama yang diperbaiki
- `www/index.html`
- `android/app/src/main/assets/index.html`

## Tes baru
- `tests/buah-masuk-date-filter-markup-regression.test.js`
