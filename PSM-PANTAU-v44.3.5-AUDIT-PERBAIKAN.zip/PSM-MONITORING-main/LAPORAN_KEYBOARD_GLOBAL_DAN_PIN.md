# Pemeriksaan keyboard global dan perbaikan PIN

## Temuan penting
Pengguna melaporkan tombol keyboard/backspace gagal di semua aplikasi, termasuk Microsoft Excel dan halaman awal Android. Gangguan lintas aplikasi tidak dapat disebabkan oleh handler input pada halaman PSM saja. Ini lebih mengarah ke aplikasi keyboard Android (IME), tema/keyboard pihak ketiga, atau masalah sentuhan layar.

## Perubahan pada source PSM Pantau
- Kolom PIN login dan pembuatan PIN diberi `inputmode=numeric`, `pattern=[0-9]*`, `enterkeyhint`, dan menonaktifkan koreksi teks.
- Input PIN pertama difokuskan saat layar kunci ditampilkan agar keyboard angka diminta otomatis.
- Perubahan sebelumnya pada pencarian sopir ongkos/gaji langsir tetap disertakan.
- Aset HTML web dan Android disamakan.

## Validasi
- `npm test`: 87 tes lulus, 0 gagal.
- Tes otomatis tidak dapat membuktikan tombol keyboard fisik/IME berfungsi di perangkat.
- Build APK dan uji HP/printer belum dilakukan.

## Pemeriksaan perangkat yang diperlukan
Karena keyboard juga gagal di Excel, pengguna perlu mencoba keyboard bawaan Android/Gboard (bukan keyboard tema/foto), mengatur ulang keyboard default, dan menguji backspace di aplikasi Catatan. Bila tetap gagal di semua aplikasi, uji sentuhan layar/keyboard pada perangkat atau layanan servis.
