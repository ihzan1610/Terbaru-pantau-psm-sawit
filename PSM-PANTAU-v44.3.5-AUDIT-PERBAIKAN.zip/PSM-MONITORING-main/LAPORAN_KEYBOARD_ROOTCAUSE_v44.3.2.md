# Pantau PSM v44.3.2 – Keyboard Input Root-Cause Cleanup

## Konfirmasi masalah
Pengguna mengonfirmasi bahwa keyboard Android normal di WhatsApp/chat dan aplikasi lain. Dengan demikian, masalah terlokalisasi pada aplikasi Pantau PSM/WebView, bukan pada Gboard secara umum.

## Temuan pada source v44.3.1
1. `pasangPencatatAktivitasPantau()` memasang listener global `keydown` dan menulis timestamp ke `localStorage` untuk setiap tombol yang ditekan. Ini adalah pekerjaan sinkron yang tidak diperlukan pada jalur input.
2. `psm-keyboard-input-runtime` menggunakan `MutationObserver` dan `focusin` untuk mengubah atribut input saat elemen difokuskan. Perubahan atribut pada waktu fokus berpotensi mengganggu sesi input method editor (IME) Android.
3. CSS PIN memakai `ime-mode:disabled`, properti nonstandar yang tidak perlu dan berpotensi mengganggu IME.
4. Penambahan pengaturan keyboard sebelumnya dilakukan secara dinamis; sekarang atribut petunjuk keyboard dipasang langsung pada markup agar tidak berubah saat pengguna mulai mengetik.

Temuan tersebut adalah sumber gangguan yang masuk akal dari kode aplikasi; pengaruh kausal akhirnya tetap harus dikonfirmasi dengan APK di perangkat.

## Perubahan v44.3.2
- Menghapus listener global `keydown` dari pencatat aktivitas. Aktivitas masih dicatat pada interaksi pointer/touch dan saat aplikasi ditinggalkan/disembunyikan.
- Menghapus MutationObserver dan perubahan atribut pada `focusin` untuk semua input.
- Mengatur autocorrect/autocapitalize/spellcheck langsung pada elemen input dan textarea.
- Mempertahankan keypad numerik untuk PIN dan masking titik PIN; menghapus `ime-mode:disabled`.
- Tidak menambahkan handler `keydown`, `keyup`, `beforeinput`, Backspace, Delete, atau event komposisi IME.
- Menyamakan HTML web dan aset Android.

## QA yang berhasil
- `npm test`: **141 tes lulus, 0 gagal**.
- 5 blok JavaScript inline lolos `node --check`.
- HTML web dan aset Android identik.
- Tes regresi memverifikasi tidak ada listener global keyboard yang memotong input dan tidak ada observer yang mengubah atribut saat fokus.

## Batas pengujian
- APK belum dibangun dalam sesi ini.
- Belum ada uji langsung pada perangkat Android pengguna, termasuk pengujian ketikan beruntun, Backspace/Delete, paste, IME composition, dan PIN.
- Karena itu, perubahan source belum boleh dianggap sebagai bukti final bahwa gejala pada perangkat sudah hilang. APK harus dibangun dan diuji pada HP sebelum dinyatakan selesai.
