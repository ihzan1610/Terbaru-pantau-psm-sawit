# Laporan Perbaikan Cetak Thermal RAWBT

## Temuan penyebab
Jalur cetak struk/rekening menggunakan `Android.openExternalUrl()` untuk membuka URI Intent RAWBT. Di `MainActivity.AndroidBridge.openExternalUrl()`, panjang URL dibatasi hanya 8.192 karakter. Payload ESC/POS dapat melewati batas tersebut, terutama ketika logo thermal dikirim sebagai bitmap. Kondisi ini memicu pesan `Tautan tidak valid` sebelum intent RAWBT dibuka.

## Perubahan
1. Menaikkan batas panjang URI intent menjadi 2 MiB dan menampilkan pesan yang lebih jelas bila payload kosong/melebihi batas.
2. Menambahkan deklarasi `<queries>` untuk paket `ru.a402d.rawbtprinter` agar pemeriksaan aplikasi tujuan dapat bekerja pada Android 11+.
3. Menyamakan `android/app/src/main/assets/index.html` dengan `www/index.html`.
4. Menambahkan tes regresi untuk batas payload, package visibility RAWBT, dan kesamaan aset HTML.

## Hasil pemeriksaan
- `npm test`: 80 tes lulus, 0 gagal.
- Build APK Android belum dijalankan di lingkungan ini karena Android SDK dan Gradle tidak tersedia.
- Uji cetak fisik tetap perlu dilakukan di HP dengan aplikasi RAWBT dan printer Bluetooth yang digunakan.

## Batasan
Perbaikan ini menangani penolakan payload besar yang cocok dengan pesan error pada screenshot. Keberhasilan akhir tetap bergantung pada RAWBT terpasang, printer terhubung, serta dukungan protokol printer.
