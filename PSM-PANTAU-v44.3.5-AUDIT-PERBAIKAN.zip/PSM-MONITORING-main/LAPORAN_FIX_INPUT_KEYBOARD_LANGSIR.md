# Laporan Perbaikan Input Keyboard – Ongkos/Gaji Langsir

## Gejala
Kolom pencarian sopir pada modal Langsir di Android menunjukkan teks yang tidak sesuai, koreksi otomatis mengganggu, dan pengguna melaporkan Backspace tidak bekerja normal.

## Perubahan
- Mengubah kedua kolom pencarian sopir (`pl-search` dan `pl-gaji-search`) dari `type=search` menjadi `type=text` dengan `inputmode=search`.
- Menonaktifkan autocorrect, autocapitalize, autocomplete, dan spellcheck agar keyboard tidak mengganti teks nama secara otomatis.
- Menambahkan `enterkeyhint=search`.
- Menangani komposisi input IME Android: daftar tidak dirender ulang ketika input masih dalam proses komposisi, lalu difilter setelah komposisi selesai.
- Fungsi render hanya membaca nilai input dan memperbarui daftar hasil; tidak menulis ulang nilai input sehingga fokus dan posisi kursor tidak sengaja diganggu.
- Menyamakan aset HTML yang dibundel untuk Android dengan `www/index.html`.

## Validasi
- `npm test`: 84 tes lulus, 0 gagal.
- Perubahan diuji melalui tes regresi statis; belum ada uji langsung pada HP/keyboard fisik.
- Build APK belum dilakukan di lingkungan ini karena Android SDK/Gradle tidak tersedia.
