const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const out = path.join(root, 'www', 'vendor');
fs.mkdirSync(out, { recursive: true });

function locate(packageName, names) {
  let entry;
  try {
    entry = require.resolve(packageName, { paths: [root] });
  } catch (error) {
    throw new Error(`Paket ${packageName} belum terpasang. Jalankan npm install terlebih dahulu. ${error.message}`);
  }

  let dir = path.dirname(entry);
  for (let i = 0; i < 8; i++) {
    for (const name of names) {
      const candidate = path.join(dir, name);
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }

  const packageRoot = path.dirname(entry);
  const wanted = new Set(names);
  function walk(folder, depth) {
    if (depth > 6) return null;
    let items;
    try { items = fs.readdirSync(folder, { withFileTypes: true }); }
    catch (_) { return null; }
    for (const item of items) {
      if (item.name === 'node_modules' || item.name.startsWith('.')) continue;
      const full = path.join(folder, item.name);
      if (item.isFile() && wanted.has(item.name)) return full;
      if (item.isDirectory()) {
        const found = walk(full, depth + 1);
        if (found) return found;
      }
    }
    return null;
  }
  const found = walk(packageRoot, 0);
  if (found) return found;
  throw new Error(`Asset ${names.join('/')} tidak ditemukan di paket ${packageName} (${entry})`);
}

const assets = [
  { pkg: 'html2canvas', names: ['html2canvas.min.js', 'html2canvas.js'], dest: 'html2canvas.min.js' },
  { pkg: 'xlsx', names: ['xlsx.full.min.js', 'xlsx.full.js'], dest: 'xlsx.full.min.js' }
];

for (const asset of assets) {
  const from = locate(asset.pkg, asset.names);
  fs.copyFileSync(from, path.join(out, asset.dest));
  console.log(`${asset.pkg}: ${from} -> www/vendor/${asset.dest}`);
}
