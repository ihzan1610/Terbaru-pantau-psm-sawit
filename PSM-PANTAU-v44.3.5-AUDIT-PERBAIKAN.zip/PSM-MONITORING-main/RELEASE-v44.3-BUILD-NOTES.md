# PSM Pantau v44.3 — build package notes

- Source archive: `PSM-PANTAU-v44.3-FULL-FEATURES-GITHUB.zip`
- Capacitor: 7.6.10
- Android compile/target SDK: 35
- Java toolchain: 21 (Android source compatibility 17)
- Gradle: 8.11.1
- Android versionCode: 47; versionName: 44.3.0
- Gradle repository mode: `PREFER_PROJECT`, required because the Capacitor Android plugin declares project repositories.
- GitHub Actions deliberately selects exactly one archive matching `PSM-PANTAU-v44.3-FULL-FEATURES-GITHUB*.zip`. It refuses to select an arbitrary/stale ZIP.
- The workflow prints the selected archive checksum and the Java source list before compilation.

The 74 original application regression tests were preserved. Two additional workflow/configuration regression tests were added. Passing JavaScript tests is not proof that the Android APK compiles; the GitHub Actions Android build must still pass.
