# PSM Pantau v44.3.3 — Pencarian nama bertahap

- Daftar Pemilik dan Sopir tidak terbuka saat kolom baru difokuskan.
- Setelah minimal satu karakter diketik, tampil hanya nama yang mengandung karakter/teks pencarian tersebut (bukan hanya awalan).
- Pilihan nama dapat disentuh untuk mengisi kolom.
- Daftar saran memakai panel mengambang terbatas dan menyesuaikan `visualViewport` Android saat keyboard tampil; panel dapat digulir dan tidak memakai popup `datalist` bawaan.
- Perilaku komposisi IME tetap didukung; tidak ada listener global untuk memotong Backspace/Delete.
- `www/index.html` dan Android packaged `assets/index.html` disamakan.

Uji otomatis: 147 tes diharapkan lulus. Build APK dan uji perangkat Android tetap perlu dilakukan melalui GitHub Actions dan HP.
