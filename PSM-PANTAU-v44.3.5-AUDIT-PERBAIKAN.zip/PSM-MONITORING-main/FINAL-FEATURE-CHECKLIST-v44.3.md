# PSM Pantau v44.3 — Feature and Build Checkpoint

## Source baseline
- Derived from `PSM-PANTAU-v44.2-FINAL-SOURCE-GITHUB.zip` (2,757,521 bytes).
- Application ID: `com.psmsawit.pantau`.
- Capacitor 7.6.10; Android API 35.
- Existing feature source and business logic retained; this checkpoint focuses on build reproducibility and dependency packaging.

## Feature areas present in source and covered by regression checks
- Buah Masuk, Cloud GET-only refresh, local emergency transactions, manual reconciliation.
- Ongkos Langsir and Gaji Langsir recap/export/thermal.
- Buah Keluar/Pabrik input, calculation constraints, sorting/filtering/report totals.
- Payment page and local payment ledger, partial allocation, batch identity/deduplication, audit/history, unallocated payment allocation, backup/restore and CSV export.
- Periodic insights, monthly/yearly reporting, weighted SPB price comparison, liabilities and anomaly checks.
- IndexedDB primary storage adapter, migration checksums, backup/restore and failure reporting.
- PIN setup and PBKDF2 verifier.

## Workflow
- Standalone `.github/workflows/build-debug-apk.yml` is included.
- Workflow matches the actual Capacitor 7 structure in this ZIP.
- Does not call the old Android Native workflow or `npx` in a project without Capacitor.

## Verification
- Original v44.2 source tests were run locally: 72/72 passed.
- Additional workflow/vendor source tests are included in this checkpoint.
- APK build on GitHub and physical-device testing have not yet been performed.

## Important scope boundary
- Android Keystore/AES-GCM transaction encryption is not implemented in this source checkpoint.
- Do not describe this package as device-certified or fully production-validated until GitHub build and Android device tests pass.
