PSM SAWIT PANTAU v44.3.2 — BUILD DEBUG APK

SOURCE
- Upload seluruh isi folder PSM-MONITORING-main ke root repository GitHub.
- Pastikan folder .github/workflows/build-debug-apk.yml ikut ter-upload.
- Jangan upload ZIP ini saja sebagai satu file; ekstrak dahulu dan upload isi foldernya.

BUILD APK DI GITHUB
1. Buka repository GitHub.
2. Buka tab Actions.
3. Pilih workflow "Build PSM Pantau v44.3.2 APK".
4. Tekan Run workflow (atau push ke branch main/master).
5. Tunggu sampai semua langkah berstatus hijau.
6. Buka hasil run yang sukses, bagian Artifacts.
7. Unduh artifact "PSM-PANTAU-v44.3.2-DEBUG-APK"; di dalamnya ada app-debug.apk.

TES
Workflow otomatis menjalankan npm test, menyalin vendor offline, sync Capacitor,
membangun APK Android, memverifikasi APK, lalu mengunggah artifact.

BUILD LOKAL
Memerlukan Node.js 22, JDK 21, Android SDK Platform 35, Build Tools 35.0.0,
dan Gradle 8.11.1:
  npm install
  npm test
  npm run android:debug

Catatan:
- APK debug tidak ditandatangani sebagai release untuk distribusi Play Store.
- Backup data penting sebelum memasang/menguji aplikasi.
- Setelah APK berhasil dibangun, uji ketikan satu huruf, ketikan cepat, Backspace,
  Delete, paste, dan PIN numerik langsung di HP.
