# PSM Pantau v44.3.3 – Stabilitas Keyboard

## Perubahan
- Semua kolom PIN menggunakan `type=password` dengan `inputmode=numeric`, sehingga keypad angka tetap diminta dan masking ditangani native browser/WebView.
- Menghapus masking PIN berbasis CSS `-webkit-text-security` yang sebelumnya dipakai pada input `type=tel`.
- Kolom pencarian pembayaran, sopir langsir, dan gaji langsir menggunakan semantik native `type=search`.
- Refresh hasil pencarian pembayaran dijadwalkan 180 ms setelah input, dengan perlindungan IME composition; tidak ada rerender pada setiap karakter mentah.
- HTML web dan aset Android disamakan byte-for-byte.
- Tidak menambahkan handler global keydown/keyup/beforeinput dan tidak mengubah atribut input saat fokus.

## Batas validasi
Tes otomatis memeriksa source, bukan perilaku Gboard pada perangkat. APK harus dibangun dan diuji langsung: ketik cepat, hapus, pindah kursor, paste, IME, PIN, pencarian, dan form angka.
