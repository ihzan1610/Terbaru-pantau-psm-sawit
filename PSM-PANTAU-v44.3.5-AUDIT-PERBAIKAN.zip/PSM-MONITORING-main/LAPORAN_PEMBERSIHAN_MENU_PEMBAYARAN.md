# Pembersihan Menu Pembayaran Pantau PSM

## Perubahan
- Dihapus tombol "Pilih yang Tertua".
- Dihapus fungsi `paySelectOldest()` yang hanya digunakan tombol tersebut.
- Tetap dihapus fitur opsional "Sarankan Prioritas" dan input anggaran.
- Dipertahankan pemilihan transaksi secara manual, catat pembayaran pilihan, ekspor Excel/CSV, filter, daftar tagihan, rekap pemilik, dan riwayat pembayaran.

## Validasi
`npm test`: 104 tes lulus, 0 gagal.
Aset HTML web dan Android disamakan.
APK belum dibangun.
