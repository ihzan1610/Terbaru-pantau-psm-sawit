# Audit dan perbaikan PSM Pantau v44.3.5

## Perubahan pada paket ini
- Mempertahankan perbaikan form Buah Keluar v44.3.4 (atribut Asal/SPB valid dan baris CASH JLY dapat disembunyikan).
- Saran Asal dan SPB tidak lagi membuka seluruh daftar saat kolom hanya disentuh; daftar baru tampil setelah pengguna mengetik dan hanya menampilkan item yang mengandung teks pencarian.
- Sumber web dan aset Android disinkronkan byte-for-byte.
- Metadata paket, versi Android, nama workflow, dan nama artifact diselaraskan ke v44.3.5.
- Menambahkan tes regresi khusus agar perilaku saran Asal/SPB tidak kembali rusak.

## Pemeriksaan yang dilakukan
- ZIP diuji integritasnya.
- Seluruh tes Node dijalankan.
- Inline JavaScript diperiksa dengan `node --check`.
- XML Android diperiksa.
- ID HTML duplikat diperiksa.

## Batas verifikasi
Build APK Gradle dan uji interaksi di perangkat Android belum dapat dijalankan dalam lingkungan audit ini. Hasil tes sumber bukan bukti APK sudah berhasil dibuat atau semua perilaku perangkat sudah bebas bug.
