# Perbaikan Form Buah Keluar v44.3.4

- Memperbaiki atribut `onblur` pada kolom Asal dan SPB yang sebelumnya rusak sehingga potongan kode JavaScript tampil sebagai teks di layar.
- Mengembalikan atribut keyboard (`autocomplete`, `autocorrect`, `autocapitalize`, `spellcheck`) sebagai atribut input HTML yang terpisah dan valid.
- Baris Sampah/Tangkai hanya ditampilkan untuk SPB `CASH JLY`; untuk SPB lain baris benar-benar disembunyikan dan tidak menyisakan ruang kosong.
- Rumus Nett, Sortasi, Nett Akhir, penyimpanan, dan validasi transaksi tidak diubah.
- Sinkronisasi sumber `www/index.html` dan aset Android tetap identik.
