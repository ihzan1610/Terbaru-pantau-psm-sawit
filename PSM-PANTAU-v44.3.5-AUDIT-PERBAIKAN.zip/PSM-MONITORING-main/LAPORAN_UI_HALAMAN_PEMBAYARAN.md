# Perapian UI Halaman Pembayaran – Pantau PSM v44.3

## Tujuan
Merapikan bagian atas halaman Pembayaran dan membuat tabel tagihan lebih mudah diurutkan serta difilter seperti Excel.

## Perubahan UI
1. Empat tindakan backup/restore tidak lagi tampil berjajar di header. Semuanya dipindahkan ke menu kecil berikon roda gigi di bagian atas Smart Payment Control.
2. Isi menu pengaturan: Backup lengkap, Restore lengkap, Backup pembayaran, Restore pembayaran.
3. Tabel Daftar Tagihan Buah Masuk kini memiliki dropdown pada kolom Tanggal, Pemilik, Tagihan, Dibayar, Sisa, dan Status.
4. Setiap dropdown menyediakan urutkan naik/turun, pencarian nilai kolom, checklist pilihan, pilih semua, hapus filter, dan terapkan.
5. Filter kolom dapat digabung dengan pencarian umum, rentang tanggal, status, dan metode pembayaran yang sudah tersedia.
6. Header kolom menunjukkan indikator ketika sortir atau filter aktif.
7. Ringkasan, aksi catat pembayaran, detail transaksi, dan riwayat pembayaran tetap dipertahankan.

## Pengujian
- `npm test`: 122 tes lulus, 0 gagal.
- 5 blok JavaScript inline lolos `node --check`.
- HTML web dan aset HTML Android identik.
- APK dan pengujian sentuh di perangkat Android belum dilakukan.

## Catatan
Sortir/filter kolom diterapkan pada tabel Daftar Tagihan. Rekap Per Pemilik dan Riwayat Pembayaran tetap mengikuti tampilan/ringkasan yang sudah ada.
