# Perbaikan kesesuaian tanggal Cloud PSM SAWIT dan Pantau

## Temuan dari screenshot
Nomor transaksi yang sama menunjukkan tanggal berbeda satu hari:
- No. 2332: aplikasi PSM SAWIT menampilkan 07-11-2026, Pantau menampilkan 06/11/26.
- No. 2331: PSM SAWIT menampilkan 06-11-2026, Pantau menampilkan 05/11/26.

Pola mundur tepat satu hari pada beberapa transaksi konsisten dengan masalah normalisasi timestamp/timezone.

## Temuan kode
Pada `normalizeKebun()`, tanggal Cloud diproses melalui `formatUntukInputDate()`. Implementasi sebelumnya memotong string pada karakter `T`, sehingga timestamp ISO yang disimpan sebagai UTC kehilangan informasi zona waktu. Bila sumber menyimpan waktu yang merepresentasikan tengah malam waktu lokal (misalnya 00:00 WIB = 17:00Z hari sebelumnya), Pantau menampilkan tanggal UTC dan mundur satu hari.

## Perubahan
- Tanggal kalender tanpa jam (`YYYY-MM-DD`) dipertahankan apa adanya.
- Tanggal format `DD/MM/YYYY` dan `DD/MM/YY` dinormalisasi tanpa pergeseran.
- Timestamp ISO yang memiliki zona waktu eksplisit dikonversi ke tanggal kalender lokal perangkat.
- Timestamp lokal tanpa zona waktu mempertahankan tanggal tertulisnya.
- Perubahan diterapkan pada normalisasi data Cloud yang menjadi sumber semua tampilan/rekap Pantau.
- Aset HTML Android disamakan dengan sumber web.

## Validasi
- `npm test`: 91 tes lulus, 0 gagal.
- Uji regresi mencakup timestamp `2026-11-06T17:00:00Z` yang di Asia/Jakarta merupakan tanggal 07-11-2026.
- APK belum dibangun atau diuji langsung pada perangkat.
- Perlu satu sampel JSON Cloud asli dari Admin untuk memastikan format timestamp yang sebenarnya dan memvalidasi kecocokan 100% terhadap sumber.
