# Perbaikan input pencarian Pembayaran

- Menonaktifkan autocorrect, autocapitalize, dan spellcheck pada kolom pencarian pembayaran.
- Menambahkan inputmode search dan enterkeyhint search.
- Menghentikan render saat IME/komposisi keyboard sedang aktif.
- Menunda render pencarian 320 ms setelah pengguna berhenti mengetik, sehingga tidak membangun ulang ringkasan/tabel pada setiap karakter.
- Tidak mengubah data transaksi, pembayaran, ataupun fungsi penyimpanan.

APK dan uji pada perangkat fisik masih perlu dilakukan.
