const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const packaged=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('payment backup and restore actions are grouped under a compact settings menu',()=>{
 const section=html.slice(html.indexOf('id="app3-container"'),html.indexOf('<div id="pay-modal"'));
 assert.match(section,/pay-settings-trigger/);
 assert.match(section,/id="pay-settings-menu"/);
 assert.match(section,/backupAllPantauData/);
 assert.match(section,/restoreAllPantauData/);
 assert.match(section,/backupPaymentBook/);
 assert.match(section,/restorePaymentBook/);
 assert.doesNotMatch(section,/card-title[^>]*>[\s\S]{0,500}BACKUP LENGKAP/);
});

test('payment table has Excel-like sort and filter controls on useful columns',()=>{
 for(const key of ['date','owner','bill','paid','remaining','status']){
  assert.ok(html.includes('data-pay-col="'+key+'"'));
  assert.ok(html.includes("openPayColumnMenu('"+key+"',this)"));
 }
 assert.match(html,/Urutkan naik/);
 assert.match(html,/Urutkan turun/);
 assert.match(html,/Cari pilihan/);
 assert.match(html,/Terapkan/);
});

test('column filters and sorting are applied to the payment table result set',()=>{
 assert.match(html,/const payColumnFilters=/);
 assert.match(html,/function payApplyColumnFilters\(rows\)/);
 assert.match(html,/return payApplyColumnFilters\(base\)/);
 assert.match(html,/function setPaySort\(key,direction\)/);
 assert.match(html,/function applyPayColumnFilter\(key\)/);
});

test('existing payment search, date, status and method filters remain in place',()=>{
 assert.match(html,/id="pay-search"/);
 assert.match(html,/id="pay-start"/);
 assert.match(html,/id="pay-end"/);
 assert.match(html,/id="pay-status"/);
 assert.match(html,/id="pay-method"/);
});

test('web and Android packaged HTML are identical',()=>assert.equal(html,packaged));
