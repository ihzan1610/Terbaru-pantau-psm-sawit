const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

function inputTag(id) {
  return html.match(new RegExp(`<input\\b(?=[^>]*\\bid="${id}")[^>]*>`, 'i'))?.[0] || '';
}

test('Buah Masuk search inputs never rewrite typed text during input events', () => {
  for (const id of ['f-name', 'f-driver']) {
    const tag = inputTag(id);
    assert.ok(tag, `missing input ${id}`);
    assert.doesNotMatch(tag, /oninput="[^"]*(?:this\\.)?value\\s*=/i);
  }
});

test('text entry fields do not uppercase by assigning input.value on every keystroke', () => {
  for (const id of ['in-owner', 'in-driver', 'p_supir', 'p_asal', 'p_spb']) {
    const tag = inputTag(id);
    assert.ok(tag, `missing input ${id}`);
    assert.doesNotMatch(tag, /oninput="[^"]*this\\.value\\s*=/i);
  }
});

test('filter and entry text normalization is read-only while typing; Android asset matches web asset', () => {
  assert.equal(html, packaged);
  assert.doesNotMatch(html, /oninput="[^"]*this\\.value\\s*=\\s*this\\.value\\.toUpperCase\(\)/i);
});
