const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('main page and payment date filters use compact selected-date controls', () => {
  for (const id of ['f-start','f-end','pay-start','pay-end']) {
    assert.ok(html.includes('data-date-target="' + id + '"'));
    assert.ok(html.includes('id="' + id + '"'));
    assert.ok(html.includes('id="' + id + '-display"'));
  }
});

test('wheel picker provides day, month and year scroll columns', () => {
  assert.ok(html.includes('id="psm-wheel-day"'));
  assert.ok(html.includes('id="psm-wheel-month"'));
  assert.ok(html.includes('id="psm-wheel-year"'));
  assert.ok(html.includes('scroll-snap-type:y mandatory'));
  assert.ok(html.includes("const months=['Januari','Februari'"));
});

test('idle display shows one selected date and hides wheel neighbors', () => {
  assert.ok(html.includes('wheel-date-value'));
  assert.ok(html.includes('Pilih tanggal'));
  assert.ok(html.includes("pad(selected.d)+' '+months[selected.m-1]+' '+selected.y"));
});

test('wheel selection updates original filter value and triggers existing filter logic', () => {
  assert.ok(html.includes('input.value=iso(selected)'));
  assert.ok(html.includes("input.dispatchEvent(new Event('change',{bubbles:true}))"));
});

test('transaction entry and non-filter date inputs are preserved', () => {
  assert.ok(html.includes('id="in-date"'));
  assert.ok(html.includes('id="pay-date-input" type="date"'));
  assert.ok(html.includes('id="pf1_start"'));
  assert.ok(html.includes('id="pl-start"'));
});

test('web and Android packaged HTML are identical', () => {
  assert.equal(html, packaged);
});
