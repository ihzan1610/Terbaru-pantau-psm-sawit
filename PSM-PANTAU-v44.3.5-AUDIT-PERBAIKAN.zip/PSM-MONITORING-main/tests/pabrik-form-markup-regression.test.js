const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('Buah Keluar Asal and SPB inputs keep valid blur handlers and separate keyboard attributes', () => {
  assert.match(html, /id="p_asal"[^>]*onblur="setTimeout\(\(\)=>hidePabrikSuggest\('p_asal'\),180\)"[^>]*autocomplete="off"/);
  assert.match(html, /id="p_spb"[^>]*onblur="setTimeout\(\(\)=>hidePabrikSuggest\('p_spb'\),180\)"[^>]*autocomplete="off"/);
  assert.doesNotMatch(html, /HIDEPABRIKSUGGEST|setTimeout\(\(\)= autocorrect|spellcheck="false">hidePabrikSuggest/);
});

test('hidden Cash JLY deduction row collapses instead of reserving a blank form block', () => {
  assert.match(html, /\.invisible\{display:none!important\}/);
  assert.match(html, /const isCash=spb==='CASH JLY';if\(row\)\{row\.classList\.toggle\('invisible',!isCash\);row\.style\.display=isCash\?'flex':'none';\}/);
  assert.doesNotMatch(html, /#app2-container #p_row_cash\.invisible\{[^}]*min-height|#app2-container #p_row_cash\{[^}]*min-height:86px/s);
});

test('web and Android packaged Pabrik form remain byte-for-byte identical', () => {
  assert.equal(packaged, html);
});
