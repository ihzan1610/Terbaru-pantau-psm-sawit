const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('PIN login and setup fields request numeric keypad and suppress text correction', () => {
  for (const id of ['input-pin', 'pin-setup-new', 'pin-setup-confirm']) {
    const tag = html.match(new RegExp('<input[^>]*id="' + id + '"[^>]*>'))?.[0] || '';
    assert.match(tag, /inputmode="numeric"/);
    assert.match(tag, /pattern="\[0-9\]\*"/);
    assert.match(tag, /autocorrect="off"/);
    assert.match(tag, /autocapitalize="off"/);
    assert.match(tag, /spellcheck="false"/);
  }
});

test('login focuses the visible PIN input after selecting login/setup mode', () => {
  assert.match(html, /pinTarget\.focus\(\{preventScroll:true\}\)/);
});

test('web and Android packaged HTML assets are identical', () => {
  assert.equal(html, packaged);
});
