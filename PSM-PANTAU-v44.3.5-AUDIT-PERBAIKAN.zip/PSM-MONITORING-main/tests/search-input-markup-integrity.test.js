const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');

test('owner and driver filters preserve native IME text and keep attributes separate', () => {
  for (const id of ['f-name', 'f-driver']) {
    const tag = html.match(new RegExp(`<input\\b(?=[^>]*\\bid="${id}")[^>]*>`, 'i'))?.[0] || '';
    assert.ok(tag, `missing ${id}`);
    assert.ok(tag.includes('oncompositionstart="monitorSearchComposing=true;clearTimeout(timerDebounce)"'));
    assert.ok(tag.includes('oncompositionend="monitorSearchComposing=false;handleMonitorSearchInput(event)"'));
    assert.ok(tag.includes('oninput="handleMonitorSearchInput(event)"'));
    assert.ok(tag.includes('autocorrect="off"'));
    assert.ok(tag.includes('autocapitalize="off"'));
    assert.doesNotMatch(tag, /this\\.value\\s*=/);
  }
  assert.match(html, /function handleMonitorSearchInput\(event\)\{/);
  assert.match(html, /if\(monitorSearchComposing\|\|event\?\.isComposing\)return/);
});
