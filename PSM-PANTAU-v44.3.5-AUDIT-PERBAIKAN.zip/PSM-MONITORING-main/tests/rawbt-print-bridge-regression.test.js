const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const java = fs.readFileSync(path.join(root, 'android/app/src/main/java/com/psmsawit/pantau/MainActivity.java'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'android/app/src/main/AndroidManifest.xml'), 'utf8');
const web = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('RAWBT native bridge accepts thermal payloads larger than 8 KB', () => {
  assert.match(java, /rawUrl\.length\(\)\s*>\s*2\s*\*\s*1024\s*\*\s*1024/);
  assert.doesNotMatch(java, /rawUrl\.length\(\)\s*>\s*8192/);
});

test('Android declares RAWBT package visibility for Android 11+', () => {
  assert.match(manifest, /<queries>[\s\S]*?<package android:name="ru\.a402d\.rawbtprinter"\s*\/>[\s\S]*?<\/queries>/);
});

test('web and packaged Android HTML remain identical', () => {
  assert.equal(web, packaged);
});
