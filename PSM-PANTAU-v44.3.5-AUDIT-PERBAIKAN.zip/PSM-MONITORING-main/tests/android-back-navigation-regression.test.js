const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'android/app/src/main/java/com/psmsawit/pantau/MainActivity.java'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('Android back bridge uses one shared app-wide handler', () => {
  assert.match(html, /window\.handleAndroidBack\s*=\s*function\(\)/);
  assert.match(html, /typeof handleNativeBack==='function'\)return !!handleNativeBack\(\)/);
  assert.doesNotMatch(html, /window\.handleAndroidBack\s*=\s*window\.handleAndroidBack\s*\|\|/);
});

test('back handler closes visible modal overlays in topmost z-index order', () => {
  assert.match(html, /querySelectorAll\('\.modal-overlay, \.langsir-modal'\)/);
  assert.match(html, /getBoundingClientRect\(\)/);
  assert.match(html, /pantau-langsir-modal/);
  assert.match(html, /closePantauLangsir\(\)/);
  assert.match(html, /closePayModal\(\)/);
  assert.match(html, /tutupModal\(id\)/);
});

test('back handler returns from both secondary app tabs', () => {
  assert.match(html, /const app3=document\.getElementById\('app3-container'\)[\s\S]*?switchTab\(1,true\)/);
  assert.match(html, /const app2=document\.getElementById\('app2-container'\)[\s\S]*?switchTab\(1,true\)/);
});

test('Android native back delegates to JavaScript handler before WebView history', () => {
  assert.match(java, /window\.handleAndroidBack\(\)/);
  assert.match(java, /webView\.canGoBack\(\)/);
});

test('popstate and Android hardware back use the same handler', () => {
  assert.match(html, /window\.handleAndroidBack==='function'[\s\S]*?window\.handleAndroidBack\(\)/);
});

test('web and Android packaged HTML assets are identical', () => {
  assert.equal(html, packaged);
});
