const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const web = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const android = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('Pemilik and Sopir use custom suggestions, not native datalist popups', () => {
  assert.match(web, /id="in-owner"[^>]*pantauNameInput/);
  assert.match(web, /id="in-driver"[^>]*pantauNameInput/);
  assert.doesNotMatch(web.match(/<input[^>]*id="in-owner"[^>]*>/)?.[0] || '', /\blist=/);
  assert.doesNotMatch(web.match(/<input[^>]*id="in-driver"[^>]*>/)?.[0] || '', /\blist=/);
});

test('name suggestions stay hidden until at least one character is entered', () => {
  assert.match(web, /if\(!q\)\{hide\(\);return;\}/);
  assert.match(web, /pantauNameFocus=\(input,kind\)=>\{if\(String\(input\.value\|\|''\)\.trim\(\)\)render\(input,kind\);else hide\(\);\}/);
});

test('name suggestions match a character anywhere in the saved name', () => {
  assert.match(web, /source\.filter\(n=>norm\(n\)\.includes\(norm\(q\)\)\)/);
});

test('suggestions adapt to Android keyboard visible viewport and remain scrollable', () => {
  assert.match(web, /window\.visualViewport/);
  assert.match(web, /position:fixed/);
  assert.match(web, /overflow-y:auto/);
  assert.match(web, /max-height: min\(210px, 28vh\)/);
});

test('web and Android HTML are identical after dropdown changes', () => {
  assert.equal(android, web);
});
