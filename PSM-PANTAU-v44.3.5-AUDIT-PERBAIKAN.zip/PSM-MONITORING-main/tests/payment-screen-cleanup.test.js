const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');

test('payment page removes automatic oldest-first and budget-priority helpers', () => {
  assert.doesNotMatch(html, /PILIH(?:KAN)? YANG TERTUA/);
  assert.doesNotMatch(html, /paySelectOldest/);
  assert.doesNotMatch(html, /SARANKAN PRIORITAS/);
  assert.doesNotMatch(html, /pay-budget/);
  assert.doesNotMatch(html, /paySuggestBudget/);
});

test('manual payment selection and recording remain available', () => {
  assert.match(html, /payToggleOne/);
  assert.match(html, /payToggleAll/);
  assert.match(html, /payBulkRecord/);
  assert.match(html, /CATAT PEMBAYARAN PILIHAN/);
});

test('payment export and payment records remain available', () => {
  assert.match(html, /exportPaymentCSV/);
  assert.match(html, /payRecordFor/);
});

test('web and Android packaged HTML remain identical', () => {
  const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');
  assert.equal(html, packaged);
});
