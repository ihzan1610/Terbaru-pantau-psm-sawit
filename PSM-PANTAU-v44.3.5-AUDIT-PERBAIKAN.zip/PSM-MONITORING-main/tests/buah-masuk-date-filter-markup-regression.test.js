const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const androidHtml = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('Buah Masuk date filter inputs have complete valid markup', () => {
  for (const id of ['f-start', 'f-end']) {
    const expected = `<input type="date" id="${id}" class="filter-input" onchange="debounceSearch(()=>{clearSelection();renderLiveTable()})" style="display:none" aria-hidden="true">`;
    assert.ok(html.includes(expected), `${id} must have a complete date input`);
    assert.ok(html.includes(`id="${id}-display"`), `${id} display button exists`);
  }
});

test('Buah Masuk filter grid has two text searches and two date pickers with no leaked code', () => {
  const start = html.indexOf('<div class="filter-grid">');
  const end = html.indexOf('<div id="k_summary"', start);
  assert.ok(start >= 0 && end > start);
  const grid = html.slice(start, end);
  assert.equal((grid.match(/id="f-name"|id="f-driver"/g) || []).length, 2);
  assert.equal((grid.match(/id="f-start"|id="f-end"/g) || []).length, 2);
  assert.equal((grid.match(/class="wheel-date-field"/g) || []).length, 2);
  assert.ok(!grid.includes('</div>{clearSelection();renderLiveTable()})'));
  assert.ok(!grid.includes('onchange="debounceSearch(()= style='));
});

test('date picker trigger ids and target ids match the wheel date picker runtime', () => {
  for (const id of ['f-start', 'f-end']) {
    assert.ok(html.includes(`data-date-target="${id}"`));
    assert.ok(html.includes(`onclick="openWheelDatePicker('${id}')"`));
    assert.ok(html.includes(`id="${id}-display"`));
  }
});

test('Android packaged HTML is byte-for-byte equal to web HTML', () => {
  assert.equal(androidHtml, html);
});
