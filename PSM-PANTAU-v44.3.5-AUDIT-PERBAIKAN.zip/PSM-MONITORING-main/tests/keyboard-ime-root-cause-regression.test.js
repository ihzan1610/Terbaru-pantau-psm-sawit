const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const android=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('no app-wide keydown handler performs synchronous storage writes while typing',()=>{
 const fn=html.match(/function pasangPencatatAktivitasPantau\(\)\{[^}]*\}/)?.[0]||'';
 assert.ok(fn);
 assert.ok(!fn.includes('keydown'));
 assert.ok(fn.includes('pointerdown'));
});

test('no focus-time MutationObserver mutates input attributes during IME composition',()=>{
 assert.ok(!html.includes('psm-keyboard-input-runtime'));
 assert.ok(!html.includes('new MutationObserver(records=>records.forEach(r=>r.addedNodes'));
});

test('PIN uses a numeric keypad while retaining password masking without disabling IME',()=>{
 const tag=html.match(/<input[^>]*id="input-pin"[^>]*>/)?.[0]||'';
 assert.ok(tag.includes('type="password"'));
 assert.ok(tag.includes('inputmode="numeric"'));
 assert.ok(!html.includes('-webkit-text-security:disc'));
 assert.ok(!html.includes('ime-mode:disabled'));
});

test('text and numeric input hints are static markup rather than focus-time mutation',()=>{
 const text=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 assert.ok(text.includes('autocorrect="off"'));
 assert.ok(text.includes('autocapitalize="off"'));
 assert.ok(text.includes('spellcheck="false"'));
 const number=html.match(/<input[^>]*id="in-w1"[^>]*>/)?.[0]||'';
 assert.ok(number.includes('inputmode="decimal"'));
});

test('no global keyboard compatibility code intercepts Backspace/Delete/IME',()=>{
 assert.ok(!/addEventListener\(['"](?:keydown|keyup|beforeinput|compositionstart|compositionend)/.test(html));
 assert.ok(!/addEventListener\(['\"](?:keydown|keyup|beforeinput|compositionstart|compositionend)[^;]*preventDefault/.test(html));
 assert.ok(!/addEventListener\(['\"](?:keydown|keyup|beforeinput|compositionstart|compositionend)[^;]*stopImmediatePropagation/.test(html));
});

test('web and Android HTML are byte-identical',()=>assert.equal(html,android));
