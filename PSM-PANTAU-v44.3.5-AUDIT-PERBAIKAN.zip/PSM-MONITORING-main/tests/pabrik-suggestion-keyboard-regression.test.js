const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('Buah Keluar suggestions stay hidden until the user types', () => {
  assert.match(html, /if\(!q\)\{box\.style\.display='none';box\.innerHTML='';return;\}/);
  assert.match(html, /getPabrikSuggestList\(type\)\.filter\(v=>v\.includes\(q\)\)/);
});

test('web and Android suggestion behavior remain identical', () => {
  assert.equal(packaged, html);
});
