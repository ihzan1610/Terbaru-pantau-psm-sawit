const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');
test('local Android build runs Gradle from android project directory',()=>{const p=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));assert.match(p.scripts['android:debug'],/cd android && gradle assembleDebug/)});
test('release version metadata is consistent',()=>{const p=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));const g=fs.readFileSync(path.join(root,'android/app/build.gradle'),'utf8');assert.equal(p.version,'44.3.0');assert.match(g,/versionCode 47/);assert.match(g,/versionName '44\.3.0'/)});
test('web and Android fallback assets match exactly',()=>{const a=fs.readFileSync(path.join(root,'www/index.html'));const b=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'));assert.deepEqual(a,b)});
