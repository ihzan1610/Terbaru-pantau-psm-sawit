const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html = fs.readFileSync(path.resolve(__dirname, '../www/index.html'), 'utf8');
const match = html.match(/function formatUntukInputDate\(tgl\)\{[\s\S]*?\n\}/);
assert.ok(match, 'date normalization function exists');
const context = { Date };
vm.createContext(context);
vm.runInContext(match[0] + ';this.formatUntukInputDate=formatUntukInputDate;', context);

test('date-only ISO values are preserved without timezone shifting', () => {
  assert.equal(context.formatUntukInputDate('2026-11-07'), '2026-11-07');
});

test('slash calendar dates are normalized as day/month/year', () => {
  assert.equal(context.formatUntukInputDate('07/11/2026'), '2026-11-07');
  assert.equal(context.formatUntukInputDate('07/11/26'), '2026-11-07');
});

test('ISO timestamp with timezone is converted to local calendar date', () => {
  // In Asia/Jakarta, 2026-11-06 17:00 UTC is 2026-11-07 00:00 local.
  const old = process.env.TZ;
  process.env.TZ = 'Asia/Jakarta';
  try {
    assert.equal(context.formatUntukInputDate('2026-11-06T17:00:00.000Z'), '2026-11-07');
    assert.equal(context.formatUntukInputDate('2026-11-07T00:00:00+07:00'), '2026-11-07');
  } finally {
    if (old === undefined) delete process.env.TZ; else process.env.TZ = old;
  }
});

test('web and packaged Android HTML remain identical', () => {
  const packaged = fs.readFileSync(path.resolve(__dirname, '../android/app/src/main/assets/index.html'), 'utf8');
  assert.equal(html, packaged);
});
