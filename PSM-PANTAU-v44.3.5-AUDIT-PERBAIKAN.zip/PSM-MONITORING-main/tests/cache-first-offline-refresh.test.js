const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const packaged = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');

test('last known-good cloud cache is restored before the first render', () => {
  assert.match(html, /KEY_KEBUN_LAST_GOOD="psm_database_monitor_last_good_v1"/);
  assert.match(html, /function loadLastGoodCloudCache\(\)/);
  assert.match(html, /let cloudKebun=loadLastGoodCloudCache\(\)/);
  assert.match(html, /function mulaiAplikasiKebun\(\)[\s\S]*?renderLiveTable\(\)/);
});

test('offline startup leaves cached cloud data intact', () => {
  const sync = html.slice(html.indexOf('async function tarikDataCloud(silent=false){'), html.indexOf('\nfunction setKebunCloudStatus'));
  assert.match(sync, /if\(!navigator\.onLine\)[\s\S]*?return false/);
  assert.match(sync, /OFFLINE • menampilkan '\+cloudKebun\.length\+' data terakhir/);
});

test('cloud response must validate count and cannot replace a non-empty cache with an empty list', () => {
  assert.match(html, /Number\(j\.count\)!==j\.data\.length/);
  assert.match(html, /j\.data\.length===0&&cloudKebun\.length>0/);
  assert.match(html, /Cache lama tidak akan ditimpa/);
});

test('successful refresh saves a last-good snapshot before replacing the main cache', () => {
  const sync = html.slice(html.indexOf('async function tarikDataCloud(silent=false){'), html.indexOf('\nfunction setKebunCloudStatus'));
  assert.ok(sync.indexOf('safeSet(KEY_KEBUN_LAST_GOOD,oldGood)') < sync.indexOf('safeSet(KEY_KEBUN,JSON.stringify(incoming))'));
  assert.match(sync, /safeSet\(KEY_KEBUN_LAST_GOOD,JSON\.stringify\(incoming\)\)/);
});

test('refresh retries once on reconnect or app foreground without background polling', () => {
  assert.match(html, /window\.addEventListener\('online'/);
  assert.match(html, /document\.addEventListener\('visibilitychange'/);
  assert.match(html, /document\.visibilityState==='visible'/);
  assert.doesNotMatch(html, /setInterval\([^)]*tarikDataCloud/);
});

test('local emergency records remain separate and are not removed by automatic refresh', () => {
  const sync = html.slice(html.indexOf('async function tarikDataCloud(silent=false){'), html.indexOf('\nfunction setKebunCloudStatus'));
  assert.match(sync, /rebuildKebunView\(\)/);
  assert.doesNotMatch(sync, /persistArchiveAndLocal\(\[\]/);
  assert.doesNotMatch(sync, /localKebun\s*=\s*\[\]/);
});

test('web and Android packaged HTML assets are identical', () => {
  assert.equal(html, packaged);
});
