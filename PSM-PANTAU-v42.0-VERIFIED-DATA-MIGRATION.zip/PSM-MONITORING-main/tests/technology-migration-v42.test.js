const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');const gradle=fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');
test('IndexedDB schema is versioned and has key/value plus metadata stores',()=>{assert.match(html,/indexedDB\.open\(DB,2\)/);assert.match(html,/createObjectStore\(META/)});
test('migration excludes PIN material and never silently overwrites existing IndexedDB rows',()=>{assert.match(html,/EXCLUDE=\/\^psm_pin_\//);assert.match(html,/!existing\.has\(k\)/)});
test('mirror records carry SHA-256 and migration verifies integrity before marking complete',()=>{assert.match(html,/sha256:hash/);assert.match(html,/await verify\(\)/);assert.match(html,/migration_v42/)});
test('migration failure is surfaced and does not claim readiness',()=>{assert.match(html,/\.catch/);assert.match(html,/window\.PSMStorageHealth\.error/)});
test('release metadata is v42',()=>{assert.match(gradle,/versionCode 42/);assert.match(gradle,/versionName '42\.0'/)});
