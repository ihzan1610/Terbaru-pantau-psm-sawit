const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');

test('main navigation order is Buah Masuk, Pembayaran, Buah Keluar', () => {
  const a = html.indexOf('id="tabBtn1"');
  const b = html.indexOf('id="tabBtn3"');
  const c = html.indexOf('id="tabBtn2"');
  assert.ok(a >= 0 && b > a && c > b);
});

test('payment page is a separate page and has no PIN prompt', () => {
  assert.match(html, /id="app3-container"/);
  assert.match(html, /SMART PAYMENT CONTROL/);
  assert.doesNotMatch(html.slice(html.indexOf('id="app3-container"'), html.indexOf('id="pay-modal"')), /cekPin\(|verifyPin\(/);
});

test('payment ledger uses its own local key and does not use Cloud write operations', () => {
  assert.match(html, /KEY_PAYMENT_BOOK="psm_private_payment_book_v1"/);
  const start = html.indexOf('/* ================= SMART PAYMENT CONTROL ================= */');
  const end = html.indexOf('function mulaiSistem()', start);
  const code = html.slice(start, end);
  assert.match(code, /safeSet\(KEY_PAYMENT_BOOK/);
  assert.doesNotMatch(code, /fetch\s*\(|method\s*:\s*['"]POST['"]|CLOUD_URL/);
});

test('payment entries support partial allocation, method, reference, and audit history', () => {
  assert.match(html, /CASH TIMBANGAN/);
  assert.match(html, /CASH RUMAH/);
  assert.match(html, /PAYMENT_ADD/);
  assert.match(html, /billAmount/);
  assert.match(html, /manualReview/);
});

test('payment backup and restore validate format before replacing local ledger', () => {
  assert.match(html, /PANTAU_PSM_PRIVATE_PAYMENT/);
  assert.match(html, /restorePaymentBook/);
  assert.match(html, /Data pembayaran lokal saat ini akan diganti/);
});
