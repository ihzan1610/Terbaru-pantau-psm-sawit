const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
test('Buah Masuk has one Admin-style Rekap Ongkos Langsir entry point', () => {
  assert.match(html, /onclick="openPantauLangsir\(\)"/);
  assert.match(html, /pl-tab-ongkos/);
  assert.match(html, /pl-tab-gaji/);
});
test('ongkos report preserves FL amount and separate deduction/net payment', () => {
  assert.match(html, /function amount\(x\)/);
  assert.match(html, /TOTAL ONGKOS LANGSIR|Total ongkos murni/);
  assert.match(html, /Potongan tambahan|POTONGAN:/);
  assert.match(html, /BERSIH DIBAYARKAN/);
  assert.match(html, /psm_langsir_payment_records_v1/);
});
test('gaji langsir accepts Rp/kg and calculates per driver from netto', () => {
  assert.match(html, /Tarif gaji langsir per kg netto/);
  assert.match(html, /Math\.round\(kg\*rate\)/);
  assert.match(html, /SLIP GAJI LANGSIR/);
});
test('ongkos and gaji have separate image, thermal and CSV actions', () => {
  assert.match(html, /previewPantauLangsir\('ongkos'/);
  assert.match(html, /previewPantauLangsir\('gaji'/);
  assert.match(html, /printPantauLangsir\('ongkos'/);
  assert.match(html, /printPantauLangsir\('gaji'/);
  assert.match(html, /exportPantauLangsir\('ongkos'/);
  assert.match(html, /exportPantauLangsir\('gaji'/);
});
