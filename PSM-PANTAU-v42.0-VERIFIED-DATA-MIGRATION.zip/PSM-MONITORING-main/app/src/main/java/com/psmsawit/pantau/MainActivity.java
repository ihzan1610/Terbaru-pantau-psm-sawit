package com.psmsawit.pantau;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceResponse;
import java.util.Locale;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 101;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingFilename = "PSM_GAMBAR.png";
    private String pendingMime = "image/png";
    private StringBuilder pendingBase64 = new StringBuilder();
    private boolean pendingTooLarge = false;
    private static final int MAX_BASE64_CHARS = 24 * 1024 * 1024;
    private static final int MAX_TEXT_BYTES = 12 * 1024 * 1024;
    private static final String ASSET_HOME = "file:///android_asset/index.html";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
            }
        }

        WebView.setWebContentsDebuggingEnabled(false);
        webView = new WebView(this);
        setContentView(webView);
        setupWindowSafeArea();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WebView.startSafeBrowsing(this, success -> { /* Safe Browsing managed by Android WebView. */ });
        }

        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "application/json",
                        "text/csv",
                        "text/plain",
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    });
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "File manager tidak ditemukan", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !request.isForMainFrame()) return false;
                return handleNavigation(request.getUrl().toString());
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                Uri uri = Uri.parse(url);
                if ("https".equalsIgnoreCase(uri.getScheme())) startActivity(new Intent(Intent.ACTION_VIEW, uri));
                else Toast.makeText(MainActivity.this, "Tautan unduhan tidak diizinkan", Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) {
                Toast.makeText(MainActivity.this, "Tidak dapat membuka unduhan", Toast.LENGTH_SHORT).show();
            }
        });

        webView.loadUrl(ASSET_HOME);
    }

    private boolean handleNavigation(String url) {
        if (url == null) return true;
        if (ASSET_HOME.equals(url) || url.startsWith("file:///android_asset/")) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if ("about".equals(scheme) && "blank".equalsIgnoreCase(uri.getSchemeSpecificPart())) return false;
        if ("intent".equals(scheme)) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                if (intent.resolveActivity(getPackageManager()) != null) startActivity(intent);
                else Toast.makeText(this, "Aplikasi tujuan tidak ditemukan", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Tautan aplikasi tidak valid", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        if ("https".equals(scheme) || "http".equals(scheme) || "whatsapp".equals(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception e) { Toast.makeText(this, "Tidak dapat membuka tautan", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    public class AndroidBridge {
        @JavascriptInterface
        public synchronized void beginBase64File(String filename, String mime) {
            pendingFilename = sanitizeFilename(filename == null ? "PSM_GAMBAR.png" : filename);
            pendingMime = safeMime(mime);
            pendingBase64 = new StringBuilder();
            pendingTooLarge = false;
        }

        @JavascriptInterface
        public synchronized void appendBase64Chunk(String chunk) {
            if (chunk == null) return;
            if (pendingTooLarge) return;
            if (pendingBase64.length() + chunk.length() > MAX_BASE64_CHARS) {
                pendingBase64 = new StringBuilder();
                pendingTooLarge = true;
                return;
            }
            pendingBase64.append(chunk);
        }

        @JavascriptInterface
        public synchronized void finishBase64File() {
            String name = pendingFilename;
            String mime = pendingMime;
            String encoded = pendingBase64.toString();
            boolean tooLarge = pendingTooLarge;
            pendingBase64 = new StringBuilder();
            pendingTooLarge = false;
            if (tooLarge) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal simpan: ukuran file melebihi batas", Toast.LENGTH_LONG).show());
                return;
            }
            try {
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                if (bytes.length > 18 * 1024 * 1024) throw new Exception("File terlalu besar");
                saveBytesToDownloads(name, mime, bytes);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "File tersimpan di Download: " + name, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal simpan file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void saveBase64File(String filename, String dataUrl) {
            try {
                String safeName = sanitizeFilename(filename == null ? "PSM_GAMBAR.png" : filename);
                if (dataUrl == null || dataUrl.length() > MAX_BASE64_CHARS + 256) throw new Exception("File terlalu besar atau kosong");
                String base64 = dataUrl;
                String mime = "image/png";
                if (dataUrl.startsWith("data:")) {
                    int comma = dataUrl.indexOf(",");
                    if (comma < 0) throw new Exception("Format data gambar tidak valid");
                    String meta = dataUrl.substring(5, comma);
                    if (meta.contains(";")) mime = meta.substring(0, meta.indexOf(";"));
                    base64 = dataUrl.substring(comma + 1);
                }
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length > 18 * 1024 * 1024) throw new Exception("File terlalu besar");
                saveBytesToDownloads(safeName, safeMime(mime), bytes);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "File tersimpan di Download: " + safeName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal simpan file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void saveTextFile(String filename, String text, String mime) {
            try {
                String safeName = sanitizeFilename(filename == null ? "PSM_DATA.txt" : filename);
                byte[] bytes = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
                if (bytes.length > MAX_TEXT_BYTES) throw new Exception("File teks terlalu besar");
                saveBytesToDownloads(safeName, safeMime(mime), bytes);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "File tersimpan di Download: " + safeName, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal simpan file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    private String safeMime(String mime) {
        if (mime == null) return "application/octet-stream";
        String m = mime.trim().toLowerCase(Locale.ROOT);
        if (m.equals("image/png") || m.equals("image/jpeg") || m.equals("image/webp") ||
            m.equals("text/plain") || m.equals("text/csv") || m.equals("application/json") ||
            m.equals("application/vnd.ms-excel") ||
            m.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") ||
            m.equals("application/octet-stream")) return m;
        return "application/octet-stream";
    }

    private String sanitizeFilename(String name) {
        if (name == null) name = "PSM_DATA";
        String safe = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]+", "_").replaceAll("\\s+", "_");
        if (safe.length() > 160) safe = safe.substring(0, 160);
        if (!safe.contains(".")) safe += ".png";
        return safe;
    }

    private void saveBytesToDownloads(String filename, String mime, byte[] bytes) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Tidak bisa membuat file Download");
            try {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("OutputStream kosong");
                    out.write(bytes);
                    out.flush();
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                if (getContentResolver().update(uri, values, null, null) <= 0) throw new Exception("Gagal menyelesaikan file Download");
            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                throw e;
            }
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, filename);
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(bytes);
            }
        }
    }


    private void setupWindowSafeArea() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(125, 186, 145));
        window.setNavigationBarColor(Color.rgb(250, 251, 245));

        if (Build.VERSION.SDK_INT >= 23) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        // Android 15/edge-to-edge: beri padding sesuai status bar agar aplikasi tidak masuk ke bar notifikasi.
        if (Build.VERSION.SDK_INT >= 30) {
            webView.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getInsets(WindowInsets.Type.statusBars()).top;
                int bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                v.setPadding(0, top, 0, bottom);
                return insets;
            });
        } else {
            webView.setFitsSystemWindows(true);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) results = new Uri[]{Uri.parse(dataString)};
                    else if (Build.VERSION.SDK_INT >= 16 && data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "(function(){try{if(window.handleAndroidBack){return window.handleAndroidBack()?'1':'0'}return '0'}catch(e){return '0'}})();",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if ("true".equals(value) || "\"1\"".equals(value) || "1".equals(value)) {
                            return;
                        }
                        if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            MainActivity.super.onBackPressed();
                        }
                    }
                }
            );
        } else {
            super.onBackPressed();
        }
    }
}
