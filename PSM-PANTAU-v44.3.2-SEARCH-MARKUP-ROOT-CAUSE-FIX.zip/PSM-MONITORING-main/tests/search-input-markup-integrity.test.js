const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');

test('owner and driver filters keep complete inline handlers and separate input attributes', () => {
  for (const id of ['f-name', 'f-driver']) {
    const start = html.indexOf('id="' + id + '"');
    assert.notEqual(start, -1, `input ${id} exists`);
    const end = html.indexOf('spellcheck="false">', start);
    const tag = html.slice(html.lastIndexOf('<input', start), end + 'spellcheck="false">'.length);
    assert.ok(tag.includes('oninput="this.value=this.value.toUpperCase();debounceSearch(()=>{clearSelection();renderLiveTable()})"'));
    assert.ok(tag.includes('autocorrect="off"'));
    assert.ok(tag.includes('autocapitalize="off"'));
    assert.ok(!tag.includes('oninput="debounceSearch(()= autocorrect='));
  }
  assert.ok(!html.includes('spellcheck="false">{clearSelection();renderLiveTable()})'));
});
