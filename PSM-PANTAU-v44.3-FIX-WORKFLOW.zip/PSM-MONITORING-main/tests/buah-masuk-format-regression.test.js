const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../android/app/src/main');
const html = fs.readFileSync(path.join(root, 'assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, '../../build.gradle'), 'utf8');
const workflow = fs.readFileSync(path.join(__dirname, '../.github/workflows/build-debug-apk.yml'), 'utf8');
function block(a,b){const i=html.indexOf(a),j=html.indexOf(b,i);assert.ok(i>=0&&j>i,`missing block ${a}`);return html.slice(i,j)}

test('image report follows Admin canvas dimensions and offline html2canvas asset',()=>{
  assert.match(html,/<script src="vendor\/html2canvas\.min\.js"><\/script>/);
  assert.doesNotMatch(html,/cdnjs\.cloudflare\.com\/ajax\/libs\/html2canvas/);
  assert.match(html,/#review-target\{[^}]*width:500px/);
  assert.match(block('async function capture(){','async function printT(){'),/scale:3/);
  assert.ok(fs.existsSync(path.join(root,'assets/vendor/html2canvas.min.js')));
  assert.match(workflow,/npm install --no-audit --no-fund/);
  assert.match(workflow,/npx cap sync android/);
  assert.match(fs.readFileSync(path.join(__dirname,'..','scripts','copy-vendor-assets.js'),'utf8'),/require\.resolve/);
});

test('Buah Masuk nota logo and operator are configurable locally',()=>{
  assert.match(html,/PANTAU_NOTA_SETTINGS_KEY='psm_pantau_nota_settings_v1'/);
  assert.match(html,/function pantauPilihLogoNota/);
  assert.match(html,/function pantauSimpanNotaSettings/);
  assert.match(html,/showLogoThermalBitmap/);
  assert.match(html,/function receiptLogoSvg\(\)\{return pantauRenderNotaLogo\(\);\}/);
});

test('single-record thermal uses individual receipt in both preview and print',()=>{
  assert.match(block('function openReview(type){','async function capture(){'),/filtered\.length===1\?buildThermalReceiptHTML/);
  assert.match(block('async function printT(){','function shareWaText(){'),/d\.list\.length===1\)parts\.push\(buildThermalReceiptText/);
});

test('multi-record thermal remains recap and keeps additional deductions',()=>{
  assert.match(block('async function printT(){','function shareWaText(){'),/buildThermalRekapText\(d\)/);
  assert.match(html,/function buildThermalRekapText\(d\)/);
  assert.match(html,/POTONGAN TAMBAHAN/);
});

test('thermal bitmap uses user logo setting and can be disabled',()=>{
  assert.match(block('async function getThermalLogoEscpos(){','function rawbtSend'),/ns\.showLogoThermalBitmap/);
  assert.match(block('async function getThermalLogoEscpos(){','function rawbtSend'),/ns\.logoDataUrl\|\|PSM_HEADER_IMG/);
});

test('release metadata now matches Pantau v44 package',()=>{
  assert.match(gradle,/versionCode 46/);
  assert.match(gradle,/versionName '44\.2-stability'/);
});
