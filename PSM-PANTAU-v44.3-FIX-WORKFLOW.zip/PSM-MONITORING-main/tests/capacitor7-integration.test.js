const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const config = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const gradle = fs.readFileSync(path.join(root, 'android/app/build.gradle'), 'utf8');
const settings = fs.readFileSync(path.join(root, 'android/settings.gradle'), 'utf8');
const activity = fs.readFileSync(path.join(root, 'android/app/src/main/java/com/psmsawit/pantau/MainActivity.java'), 'utf8');
const bridgePlugin = fs.readFileSync(path.join(root, 'android/app/src/main/java/com/psmsawit/pantau/LegacyAndroidBridgePlugin.java'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-debug-apk.yml'), 'utf8');
test('Capacitor packages are pinned to the same 7.x release', () => {
  for (const name of ['@capacitor/android','@capacitor/core','@capacitor/cli']) assert.equal(pkg.dependencies?.[name] || pkg.devDependencies?.[name], '7.6.10');
});
test('Capacitor config points at the checked-in web source', () => {
  assert.equal(config.appId, 'com.psmsawit.pantau'); assert.equal(config.webDir, 'www');
  assert.ok(fs.existsSync(path.join(root, 'www/index.html')));
});
test('Android Gradle project links Capacitor 7 runtime and API 35', () => {
  assert.match(gradle, /versionCode 46/); assert.match(gradle, /versionName '44\.2-stability'/);
  assert.match(gradle, /compileSdk 35/); assert.match(gradle, /minSdk 23/);
  assert.match(gradle, /project\(':capacitor-android'\)/); assert.match(settings, /node_modules\/@capacitor\/android\/capacitor/);
});
test('Capacitor BridgeActivity retains legacy save/share JS bridges', () => {
  assert.match(activity, /extends BridgeActivity/); assert.match(activity, /registerPlugin\(LegacyAndroidBridgePlugin\.class\)/);
  assert.match(bridgePlugin, /addJavascriptInterface\(activity\.new AndroidBridge\(\), \"Android\"\)/);
  assert.match(bridgePlugin, /addJavascriptInterface\(activity\.new AndroidShareBridge\(\), \"AndroidShare\"\)/);
  assert.match(activity, /openExternalUrl/); assert.match(activity, /beginBase64File/); assert.match(activity, /saveTextFile/); assert.match(activity, /FileProvider/);
});
test('GitHub workflow syncs Capacitor before building APK with Java 21', () => {
  assert.match(workflow, /java-version: '21'/); assert.match(workflow, /npx cap sync android/);
  assert.match(workflow, /gradle assembleDebug/); assert.match(workflow, /upload-artifact@v4/);
});

test('Capacitor web source and preserved HTML reference remain identical', () => {
  const source = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
  const reference = fs.readFileSync(path.join(root, 'android/app/src/main/assets/index.html'), 'utf8');
  assert.equal(source, reference);
});
