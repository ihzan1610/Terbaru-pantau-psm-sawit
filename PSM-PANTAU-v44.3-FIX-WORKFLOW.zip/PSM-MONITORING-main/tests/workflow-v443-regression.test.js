const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
test('v44.3 workflow targets the actual Capacitor project structure',()=>{
 const w=fs.readFileSync(path.join(root,'.github/workflows/build-debug-apk.yml'),'utf8');
 for(const f of ['package.json','capacitor.config.json','www/index.html','android/settings.gradle','android/app/build.gradle']) assert.ok(w.includes(f));
 assert.match(w,/npx cap sync android/);
 assert.match(w,/gradle assembleDebug/);
 assert.doesNotMatch(w,/android-actions\/setup-android/);
});
test('vendor copy script resolves package assets rather than hardcoded dist paths',()=>{
 const s=fs.readFileSync(path.join(root,'scripts/copy-vendor-assets.js'),'utf8');
 assert.match(s,/require\.resolve/);
 assert.match(s,/html2canvas/);
 assert.match(s,/xlsx/);
});
