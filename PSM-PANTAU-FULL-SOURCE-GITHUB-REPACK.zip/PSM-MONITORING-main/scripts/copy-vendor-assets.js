const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'www', 'vendor');
fs.mkdirSync(out, { recursive: true });
for (const [src, dst] of [
  ['html2canvas/dist/html2canvas.min.js', 'html2canvas.min.js'],
  ['xlsx/dist/xlsx.full.min.js', 'xlsx.full.min.js']
]) {
  const from = path.join(root, 'node_modules', src);
  if (!fs.existsSync(from)) throw new Error(`Dependency asset missing: ${src}`);
  fs.copyFileSync(from, path.join(out, dst));
}
console.log('Vendor assets copied to www/vendor');
