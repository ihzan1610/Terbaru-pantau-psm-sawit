# Perbaikan Backspace dan input pencarian Pembayaran v44.3.7

## Temuan
- Tidak ditemukan listener global yang memblokir tombol Backspace/Delete.
- Kolom pencarian sebelumnya menggunakan inputmode search dan status komposisi IME yang dapat membuat perilaku Gboard/WebView tidak konsisten pada perangkat tertentu.
- Pembaruan hasil pencarian perlu menjaga fokus dan posisi kursor.

## Perubahan
- Kolom pencarian memakai inputmode text dan enterkeyhint done.
- Backspace/Delete dibiarkan bekerja secara native; tidak ada preventDefault.
- Penanganan compositionend dipisahkan dari input biasa.
- Render hasil ditunda dan tidak berjalan selama IME sedang menyusun teks.
- Fokus serta posisi caret dipulihkan setelah render.
- HTML web dan Android disamakan.

## Validasi
- 153/153 tes otomatis lulus.
- Belum ada klaim pengujian APK pada perangkat fisik; wajib diuji pada HP dengan Gboard untuk memastikan perilaku Backspace dan penghapusan seleksi.
