# Root Cause Fix – Pantau PSM v44.4.0 (Android keyboard)

## Diagnosis
The user's Android keyboard (Gboard) types normally in WhatsApp, while text is duplicated inside Pantau PSM. The source configuration had:

`android.captureInput: true`

Capacitor documents this option as an alternate InputConnection for capturing JavaScript keys. Capacitor's Android WebView implementation uses a BaseInputConnection when enabled and has an ACTION_MULTIPLE path that appends event characters to the active element's value. This is a plausible direct cause of duplicated committed text when it conflicts with the normal WebView/IME input path.

## Fix applied
- Set `android.captureInput` to `false`, selecting the standard Android WebView InputConnection.
- Did not add custom JavaScript key handling, synthetic text insertion, value rewriting, or caret manipulation.
- Kept the earlier conservative search-input changes in place.
- Updated app metadata to versionName/package version `44.4.0` and Android versionCode `48`.
- Added a regression test verifying captureInput is disabled and MainActivity does not implement its own dispatchKeyEvent text insertion.
- Updated test expectations for the new version.

## Automated validation
`npm test`: **155 passed, 0 failed**.

## Build / device test status
This ZIP contains the updated source. An APK has not been built or installed in this session. The actual confirmation test must be done on the user's phone after building/installing v44.4.0:
1. Type `aansukrimah` in Buah Masuk owner filter.
2. Type `ahmad` in Pembayaran search.
3. Test fast typing, Backspace repeatedly, and deleting selected text.
4. Confirm text is inserted once and Backspace removes it normally.

## Important installation note
Build a fresh APK from this v44.4.0 source. Do not reuse a previously downloaded `app-debug.apk` from an older build folder.
