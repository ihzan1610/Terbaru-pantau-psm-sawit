const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');

test('owner and driver filters do not rerender while Android IME is typing', () => {
  for (const id of ['f-name', 'f-driver']) {
    const tag = html.match(new RegExp(`<input\\b(?=[^>]*\\bid="${id}")[^>]*>`, 'i'))?.[0] || '';
    assert.ok(tag, `missing ${id}`);
    assert.ok(tag.includes('oninput="handleMonitorSearchInput(event)"'));
    assert.ok(tag.includes('onblur="handleMonitorSearchBlur()"'));
    assert.ok(tag.includes('autocorrect="off"'));
    assert.ok(tag.includes('autocapitalize="off"'));
    assert.doesNotMatch(tag, /oncompositionstart|oncompositionend/);
  }
  const inputFn = html.match(/function handleMonitorSearchInput\(event\)\{[\s\S]*?\n\}/)?.[0] || '';
  assert.ok(inputFn);
  assert.doesNotMatch(inputFn, /renderLiveTable|focus\(|value\s*=/);
  assert.match(html, /function handleMonitorSearchBlur\(\)/);
  assert.match(html, /clearSelection\(\);\s*renderLiveTable\(\);/);
});
