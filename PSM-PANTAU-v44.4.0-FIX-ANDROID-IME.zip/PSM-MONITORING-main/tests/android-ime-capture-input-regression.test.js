const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const cfg=JSON.parse(fs.readFileSync(path.join(root,'capacitor.config.json'),'utf8'));
const webview=fs.readFileSync(path.join(root,'android/app/src/main/java/com/psmsawit/pantau/MainActivity.java'),'utf8');

test('Android uses the standard WebView InputConnection instead of Capacitor captureInput',()=>{
  assert.equal(cfg.android.captureInput,false);
});
test('app does not install a custom key dispatcher that appends ACTION_MULTIPLE text',()=>{
  assert.doesNotMatch(webview,/dispatchKeyEvent\s*\(/);
});
