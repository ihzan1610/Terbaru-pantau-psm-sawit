const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../android/app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(__dirname,'../android/app/build.gradle'),'utf8');
test('priority 3 insight panel is present and has month/year/all periods',()=>{
 assert.match(html,/id="smart-business-insights"/);
 assert.match(html,/value="month">BULANAN/);
 assert.match(html,/value="year">TAHUNAN/);
 assert.match(html,/value="all">SEMUA DATA/);
});
test('monthly and yearly reports filter valid ISO dates',()=>{
 assert.match(html,/function smartPeriodRows\(rows,mode,period\)/);
 assert.match(html,/t\.slice\(0,4\)===period/);
 assert.match(html,/t\.slice\(0,7\)===period/);
});
test('capital estimate uses matching Buah Masuk period and is qualified when absent',()=>{
 assert.match(html,/const kebunPeriod=smartPeriodRows\(dbKebun,mode,period\)/);
 assert.match(html,/const modal=kebunPeriod\.reduce/);
 assert.match(html,/Estimasi laba belum dapat dipastikan/);
});
test('SPB price comparison uses weighted average by nett akhir',()=>{
 assert.match(html,/PERBANDINGAN HARGA JUAL PER SPB/);
 assert.match(html,/g\.value\/g\.kg/);
 assert.match(html,/g\.kg\+=kg/);
});
test('cash needs are presented as outstanding liabilities, not due-date forecast',()=>{
 assert.match(html,/KEBUTUHAN KAS PEMBAYARAN KEBUN/);
 assert.match(html,/overdue7/);
 assert.match(html,/overdue30/);
 assert.match(html,/bukan jatuh tempo resmi atau ramalan kas/);
});
test('anomaly checks are read-only and cover core Pabrik fields',()=>{
 for(const x of ['badDate','badWeight','missingPrice','missingDriver','netMismatch','netOver'])assert.match(html,new RegExp(x));
 assert.match(html,/tidak mengubah atau menghapus data secara otomatis/);
});
test('new insights are refreshed with dashboard calculations',()=>assert.match(html,/updateTrendAnalysis\(\);renderSmartBusinessInsights\(\)/));
test('version metadata bumped to v44',()=>{assert.match(gradle,/versionCode 48/);assert.match(gradle,/versionName '44\.4.0'/)});
