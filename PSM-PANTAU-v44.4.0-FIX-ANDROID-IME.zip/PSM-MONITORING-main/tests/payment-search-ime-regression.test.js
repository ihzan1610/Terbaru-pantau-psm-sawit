const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
const packaged=fs.readFileSync(path.join(root,'android/app/src/main/assets/index.html'),'utf8');

test('payment search uses a plain text input and disables text correction',()=>{
 const tag=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 assert.ok(tag.includes('type="text"'));
 assert.ok(tag.includes('inputmode="text"'));
 assert.ok(tag.includes('enterkeyhint="done"'));
 for(const attr of ['autocomplete="off"','autocapitalize="off"','autocorrect="off"','spellcheck="false"'])assert.ok(tag.includes(attr),attr);
});

test('payment search waits for IME composition and debounces rendering',()=>{
 const tag=html.match(/<input[^>]*id="pay-search"[^>]*>/)?.[0]||'';
 assert.match(tag,/oncompositionstart=/);
 assert.match(tag,/oncompositionend="handlePaymentSearchCompositionEnd\(event\)"/);
 assert.match(html,/if\(paymentSearchComposing\|\|event\?\.isComposing\)return/);
 assert.match(html,/function handlePaymentSearchCompositionEnd\(event\)/);
 assert.match(html,/schedulePaymentSearchRender\(event\?\.inputType\?\.startsWith\('delete'\)\?120:250\)/);
});

test('payment search does not rewrite the input value',()=>{
 const fn=html.match(/function handlePaymentSearchInput\(event\)\{[\s\S]*?\n\}/)?.[0]||'';
 assert.ok(fn);
 assert.ok(!/\.value\s*=/.test(fn));
 assert.ok(!/innerHTML/.test(fn));
});

test('debounced results update never refocuses the active search field',()=>{
 const fn=html.match(/function schedulePaymentSearchRender\(delay=250\)\{[\s\S]*?\n\}/)?.[0]||'';
 assert.ok(fn);
 assert.match(fn,/renderPaymentPage\(\)/);
 assert.doesNotMatch(fn,/\.focus\(/);
 assert.doesNotMatch(fn,/setSelectionRange/);
 assert.doesNotMatch(html,/handlePaymentSearchKeydown/);
});

test('web and Android payment search implementations are identical',()=>assert.equal(html,packaged));
