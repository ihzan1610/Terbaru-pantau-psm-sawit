# Laporan Perbaikan Pantau PSM – Filter Buah Masuk / Keyboard Android

## Gejala terbaru
Pengguna mengetik `aansukrimah` pada kolom filter Pemilik/Sopir di halaman Buah Masuk, tetapi teks yang tampil menjadi rangkaian karakter berulang. Gejala muncul juga di luar halaman Pembayaran.

## Analisis source
- Filter `f-name` dan `f-driver` sebelumnya memanggil `renderLiveTable()` melalui debounce saat event input/composition.
- Walaupun fungsi tersebut tidak menulis `input.value`, pembaruan tabel dan ringkasan saat Gboard/WebView masih aktif dapat memicu masalah pada sebagian kombinasi IME/WebView.
- Karena itu, jalur filter utama dibuat lebih konservatif: tidak ada pembaruan DOM selama kolom pencarian masih fokus.

## Perubahan lanjutan
1. Kolom Pemilik dan Sopir tidak lagi memasang handler compositionstart/compositionend yang memicu render.
2. Event input hanya menandai filter sebagai tertunda; tidak mengubah nilai, fokus, atau caret dan tidak merender tabel.
3. Tabel dan ringkasan diperbarui satu kali setelah pengguna keluar dari kolom pencarian (blur).
4. Aset web dan Android disamakan byte-for-byte.
5. Tes regresi diperbarui untuk memverifikasi tidak ada render selama pengguna mengetik.

## Hasil tes
- `npm test`: **153 lulus, 0 gagal**.
- Ini adalah tes source/regresi, bukan uji Gboard secara langsung.

## Catatan penggunaan
Untuk menjaga kestabilan IME, hasil filter Pemilik/Sopir sekarang diperbarui setelah kolom pencarian ditinggalkan (misalnya mengetuk kolom tanggal atau area lain), bukan saat setiap karakter sedang diketik.

## Batasan
- Belum ada build APK atau pengujian langsung di HP pengguna.
- Setelah build, uji `aansukrimah`, ketik cepat, Backspace berulang, seleksi teks lalu hapus, serta kedua kolom filter secara bergantian.
